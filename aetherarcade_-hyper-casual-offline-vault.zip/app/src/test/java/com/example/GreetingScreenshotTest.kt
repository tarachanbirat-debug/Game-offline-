package com.example

import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onRoot
import com.example.data.VaultProfileEntity
import com.example.ui.screens.ArcadeHubScreen
import com.example.ui.theme.AetherArcadeTheme
import com.github.takahirom.roborazzi.RobolectricDeviceQualifiers
import com.github.takahirom.roborazzi.captureRoboImage
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(qualifiers = RobolectricDeviceQualifiers.Pixel8, sdk = [36])
class GreetingScreenshotTest {

  @get:Rule val composeTestRule = createComposeRule()

  @Test
  fun arcade_hub_screenshot() {
    composeTestRule.setContent {
      AetherArcadeTheme {
        ArcadeHubScreen(
          profile = VaultProfileEntity(),
          gameStats = emptyList(),
          selectedCategory = "All",
          onSelectCategory = {},
          onLaunchGame = { _, _, _ -> }
        )
      }
    }

    composeTestRule.onRoot().captureRoboImage(filePath = "src/test/screenshots/arcade_hub.png")
  }
}
