package com.example.games.cybersnake

import android.content.Context
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.engine.audio.SoundEngine
import com.example.engine.fx.FloatingTextController
import com.example.engine.fx.ParticleSystem
import com.example.engine.fx.ScreenShakeController
import com.example.engine.haptics.HapticEngine
import com.example.ui.components.CrtScanlinesOverlay
import com.example.ui.components.GameHudHeader
import com.example.ui.components.GameOverDialog
import com.example.ui.components.GamePauseDialog
import com.example.ui.theme.CyberDark
import com.example.ui.theme.HotMagenta
import com.example.ui.theme.LiquidGold
import com.example.ui.theme.MatrixGreen
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.SolarOrange
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

data class SnakeSegment(var x: Float, var y: Float)

data class FoodOrb(
    val id: Int,
    val x: Float,
    val y: Float,
    val isGolden: Boolean = false,
    val points: Int = 100,
    var pulseTime: Float = 0f
)

@Composable
fun CyberSnakeGame(
    soundEngine: SoundEngine,
    hapticEngine: HapticEngine,
    crtEnabled: Boolean,
    bestHighScore: Long,
    onScoreFinished: (Long, Int) -> Unit,
    onExitGame: () -> Unit
) {
    val context = LocalContext.current

    var score by remember { mutableLongStateOf(0L) }
    var streak by remember { mutableIntStateOf(1) }
    var fps by remember { mutableIntStateOf(60) }
    var isPaused by remember { mutableStateOf(false) }
    var isGameOver by remember { mutableStateOf(false) }

    // Snake Vector State
    val segments = remember { mutableListOf<SnakeSegment>() }
    var angle by remember { mutableStateOf(0f) } // radians
    var targetAngle by remember { mutableStateOf(0f) }
    var speed by remember { mutableStateOf(5.5f) }
    val baseRadius = 14f

    // Food State
    val foods = remember { mutableListOf<FoodOrb>() }

    val particles = remember { ParticleSystem(220) }
    val floatingTexts = remember { FloatingTextController() }
    val screenShake = remember { ScreenShakeController() }

    var gameWidth by remember { mutableStateOf(1080f) }
    var gameHeight by remember { mutableStateOf(1920f) }
    var isInitialized by remember { mutableStateOf(false) }

    // Virtual Joystick input
    var joystickCenter by remember { mutableStateOf<Offset?>(null) }
    var joystickThumb by remember { mutableStateOf<Offset?>(null) }

    fun spawnFood(w: Float, h: Float, count: Int = 4) {
        val margin = 80f
        for (i in 0 until count) {
            val isGold = Random.nextFloat() < 0.25f
            foods.add(
                FoodOrb(
                    id = Random.nextInt(),
                    x = margin + Random.nextFloat() * (w - 2 * margin),
                    y = margin + 120f + Random.nextFloat() * (h - 2 * margin - 120f),
                    isGolden = isGold,
                    points = if (isGold) 250 else 100
                )
            )
        }
    }

    fun resetGame() {
        score = 0L
        streak = 1
        speed = 5.5f
        angle = 0f
        targetAngle = 0f
        isGameOver = false
        isPaused = false
        particles.clear()
        floatingTexts.clear()
        screenShake.reset()
        foods.clear()
        segments.clear()

        val startX = gameWidth / 2f
        val startY = gameHeight / 2f
        val initialLength = 18
        for (i in 0 until initialLength) {
            segments.add(SnakeSegment(startX - i * 12f, startY))
        }

        spawnFood(gameWidth, gameHeight, count = 6)
    }

    LaunchedEffect(isPaused, isGameOver, isInitialized) {
        if (!isInitialized || isPaused || isGameOver) return@LaunchedEffect

        var lastNano = System.nanoTime()
        var frameCount = 0
        var fpsTimer = 0f

        while (!isPaused && !isGameOver) {
            withFrameNanos { now ->
                val dt = ((now - lastNano) / 1_000_000_000f).coerceIn(0.001f, 0.033f)
                lastNano = now

                frameCount++
                fpsTimer += dt
                if (fpsTimer >= 0.5f) {
                    fps = (frameCount / fpsTimer).toInt()
                    frameCount = 0
                    fpsTimer = 0f
                }

                screenShake.update(dt)
                particles.update(dt)
                floatingTexts.update(dt)

                // Smooth turning toward targetAngle
                var diff = targetAngle - angle
                while (diff < -Math.PI) diff += (2 * Math.PI).toFloat()
                while (diff > Math.PI) diff -= (2 * Math.PI).toFloat()
                angle += diff * 0.18f

                val head = segments.first()
                val nextHeadX = head.x + cos(angle) * speed
                val nextHeadY = head.y + sin(angle) * speed

                // Wall Collision Check (cyber walls)
                val wallMargin = 30f
                if (nextHeadX < wallMargin || nextHeadX > gameWidth - wallMargin ||
                    nextHeadY < wallMargin + 100f || nextHeadY > gameHeight - wallMargin - 40f
                ) {
                    // Crash on wall
                    isGameOver = true
                    soundEngine.playGameOverChord()
                    hapticEngine.heavyShockwave(context)
                    screenShake.addTrauma(0.6f)
                    particles.burst(head.x, head.y, 35, listOf(HotMagenta, SolarOrange, Color.White))
                    onScoreFinished(score, streak)
                    return@withFrameNanos
                }

                // Move body segments following head smoothly
                val prevHeadX = head.x
                val prevHeadY = head.y
                head.x = nextHeadX
                head.y = nextHeadY

                var prevX = prevHeadX
                var prevY = prevHeadY
                val segmentDistance = 10.5f

                for (i in 1 until segments.size) {
                    val seg = segments[i]
                    val dx = seg.x - prevX
                    val dy = seg.y - prevY
                    val dist = hypot(dx, dy)
                    if (dist > segmentDistance) {
                        val factor = segmentDistance / dist
                        val nx = prevX + dx * factor
                        val ny = prevY + dy * factor
                        prevX = seg.x
                        prevY = seg.y
                        seg.x = nx
                        seg.y = ny
                    } else {
                        prevX = seg.x
                        prevY = seg.y
                    }
                }

                // Self-collision check (skip first 10 segments near head)
                for (i in 12 until segments.size) {
                    val s = segments[i]
                    if (hypot(head.x - s.x, head.y - s.y) < baseRadius * 1.3f) {
                        isGameOver = true
                        soundEngine.playGameOverChord()
                        hapticEngine.heavyShockwave(context)
                        screenShake.addTrauma(0.5f)
                        particles.burst(head.x, head.y, 30, listOf(HotMagenta, NeonCyan, Color.White))
                        onScoreFinished(score, streak)
                        return@withFrameNanos
                    }
                }

                // Check Food Eaten
                val foodIter = foods.iterator()
                while (foodIter.hasNext()) {
                    val food = foodIter.next()
                    food.pulseTime += dt * 4f
                    val dist = hypot(head.x - food.x, head.y - food.y)
                    if (dist < baseRadius + 22f) {
                        foodIter.remove()
                        val pts = food.points * streak
                        score += pts
                        streak++
                        soundEngine.playScoreChime()
                        hapticEngine.impact(context)
                        screenShake.addTrauma(0.12f)
                        floatingTexts.spawn("+$pts", food.x, food.y - 20f, if (food.isGolden) LiquidGold else NeonCyan)

                        // Grow snake by appending segments at tail
                        val tail = segments.last()
                        repeat(if (food.isGolden) 5 else 3) {
                            segments.add(SnakeSegment(tail.x, tail.y))
                        }

                        particles.burst(
                            food.x,
                            food.y,
                            20,
                            if (food.isGolden) listOf(LiquidGold, SolarOrange, Color.White)
                            else listOf(MatrixGreen, NeonCyan, Color.White)
                        )

                        // Gradually increase speed as snake grows
                        speed = (5.5f + (segments.size / 30f)).coerceAtMost(9.5f)
                    }
                }

                if (foods.size < 4) {
                    spawnFood(gameWidth, gameHeight, count = 3)
                }
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberDark)
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { startPos ->
                        joystickCenter = startPos
                        joystickThumb = startPos
                    },
                    onDrag = { change, dragAmount ->
                        change.consume()
                        val center = joystickCenter ?: return@detectDragGestures
                        val newThumb = (joystickThumb ?: center) + dragAmount
                        val offset = newThumb - center
                        val maxRadius = 90f
                        val dist = offset.getDistance()
                        joystickThumb = if (dist > maxRadius) {
                            center + offset * (maxRadius / dist)
                        } else {
                            newThumb
                        }
                        targetAngle = atan2(offset.y, offset.x)
                    },
                    onDragEnd = {
                        joystickCenter = null
                        joystickThumb = null
                    },
                    onDragCancel = {
                        joystickCenter = null
                        joystickThumb = null
                    }
                )
            }
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            if (!isInitialized) {
                gameWidth = size.width
                gameHeight = size.height
                resetGame()
                isInitialized = true
            }

            val shake = screenShake.getOffset()

            // Cyberpunk Boundary Walls with glowing border
            val wallMargin = 30f
            val topBound = wallMargin + 100f
            val botBound = size.height - wallMargin - 40f
            val rightBound = size.width - wallMargin

            drawRect(
                color = MatrixGreen.copy(alpha = 0.2f),
                topLeft = Offset(wallMargin - 4f + shake.x, topBound - 4f + shake.y),
                size = androidx.compose.ui.geometry.Size(rightBound - wallMargin + 8f, botBound - topBound + 8f),
                style = Stroke(width = 4f)
            )
            drawRect(
                color = MatrixGreen.copy(alpha = 0.8f),
                topLeft = Offset(wallMargin + shake.x, topBound + shake.y),
                size = androidx.compose.ui.geometry.Size(rightBound - wallMargin, botBound - topBound),
                style = Stroke(width = 2f)
            )

            // Draw Foods
            for (f in foods) {
                val pulse = (sin(f.pulseTime) + 1f) * 0.5f
                val color = if (f.isGolden) LiquidGold else MatrixGreen
                // Halo Glow
                drawCircle(
                    color = color.copy(alpha = 0.35f + pulse * 0.25f),
                    radius = 24f + pulse * 8f,
                    center = Offset(f.x + shake.x, f.y + shake.y)
                )
                // Core Orb
                drawCircle(
                    color = color,
                    radius = 12f + pulse * 2f,
                    center = Offset(f.x + shake.x, f.y + shake.y)
                )
                drawCircle(
                    color = Color.White,
                    radius = 5f,
                    center = Offset(f.x + shake.x, f.y + shake.y)
                )
            }

            // Draw Snake Segments with glowing cyber gradient
            for (i in segments.indices.reversed()) {
                val s = segments[i]
                val t = i.toFloat() / segments.size.coerceAtLeast(1)
                val radius = baseRadius * (1f - t * 0.35f)
                val segColor = if (i == 0) {
                    NeonCyan
                } else {
                    val r = (MatrixGreen.red * (1f - t) + HotMagenta.red * t)
                    val g = (MatrixGreen.green * (1f - t) + HotMagenta.green * t)
                    val b = (MatrixGreen.blue * (1f - t) + HotMagenta.blue * t)
                    Color(r, g, b, 0.95f)
                }

                // Outer aura glow
                drawCircle(
                    color = segColor.copy(alpha = 0.35f),
                    radius = radius * 1.7f,
                    center = Offset(s.x + shake.x, s.y + shake.y)
                )
                // Body segment
                drawCircle(
                    color = segColor,
                    radius = radius,
                    center = Offset(s.x + shake.x, s.y + shake.y)
                )
                // Core shine
                drawCircle(
                    color = Color.White.copy(alpha = 0.6f),
                    radius = radius * 0.4f,
                    center = Offset(s.x + shake.x, s.y + shake.y)
                )
            }

            // Snake Eyes on Head
            if (segments.isNotEmpty()) {
                val head = segments.first()
                val eyeOffset = 6f
                val eyeLeftX = head.x + cos(angle + 0.6f) * eyeOffset + shake.x
                val eyeLeftY = head.y + sin(angle + 0.6f) * eyeOffset + shake.y
                val eyeRightX = head.x + cos(angle - 0.6f) * eyeOffset + shake.x
                val eyeRightY = head.y + sin(angle - 0.6f) * eyeOffset + shake.y
                drawCircle(color = Color.White, radius = 3.5f, center = Offset(eyeLeftX, eyeLeftY))
                drawCircle(color = Color.White, radius = 3.5f, center = Offset(eyeRightX, eyeRightY))
            }

            // Render Particles & Floating Text
            particles.render(this)
            floatingTexts.render(this)

            // Draw Virtual Joystick if active
            val center = joystickCenter
            val thumb = joystickThumb
            if (center != null && thumb != null) {
                drawCircle(
                    color = NeonCyan.copy(alpha = 0.2f),
                    radius = 90f,
                    center = center
                )
                drawCircle(
                    color = NeonCyan.copy(alpha = 0.7f),
                    radius = 90f,
                    center = center,
                    style = Stroke(2f)
                )
                drawCircle(
                    color = NeonCyan.copy(alpha = 0.85f),
                    radius = 32f,
                    center = thumb
                )
            }
        }

        // CRT Scanline Overlay
        CrtScanlinesOverlay(enabled = crtEnabled)

        // Top HUD
        GameHudHeader(
            gameTitle = "CYBER SNAKE 360",
            score = score,
            fps = fps,
            streak = streak,
            accentColor = MatrixGreen,
            onPauseClick = { isPaused = true },
            modifier = Modifier.statusBarsPadding()
        )

        // Pause Menu
        GamePauseDialog(
            isOpen = isPaused,
            gameTitle = "Cyber Snake 360",
            score = score,
            onResume = { isPaused = false },
            onRestart = { resetGame() },
            onExit = onExitGame,
            isSoundOn = soundEngine.isSoundEnabled.value,
            onToggleSound = { soundEngine.setSoundEnabled(!soundEngine.isSoundEnabled.value) }
        )

        // Game Over Menu
        GameOverDialog(
            isOpen = isGameOver,
            gameTitle = "Cyber Snake 360",
            score = score,
            highScore = maxOf(bestHighScore, score),
            isNewHighScore = score > bestHighScore,
            coinsEarned = (score / 10).coerceAtLeast(5),
            onRestart = { resetGame() },
            onExit = onExitGame
        )
    }
}
