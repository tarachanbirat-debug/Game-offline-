package com.example.games.brickbreaker

import android.content.Context
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.engine.audio.SoundEngine
import com.example.engine.fx.FloatingTextController
import com.example.engine.fx.ParticleSystem
import com.example.engine.fx.ScreenShakeController
import com.example.engine.haptics.HapticEngine
import com.example.ui.components.CrtScanlinesOverlay
import com.example.ui.components.GameHudHeader
import com.example.ui.components.GameOverDialog
import com.example.ui.components.GamePauseDialog
import com.example.ui.theme.CyberDark
import com.example.ui.theme.HotMagenta
import com.example.ui.theme.LaserRed
import com.example.ui.theme.LiquidGold
import com.example.ui.theme.MatrixGreen
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.SolarOrange
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

data class Brick(
    val id: Int,
    val x: Float,
    val y: Float,
    val width: Float,
    val height: Float,
    val color: Color,
    var hp: Int,
    val maxHp: Int,
    val points: Int,
    val hasPowerUp: Boolean = false
)

data class Ball(
    var x: Float,
    var y: Float,
    var vx: Float,
    var vy: Float,
    val radius: Float = 14f,
    val trail: MutableList<Offset> = mutableListOf()
)

data class PowerUpDrop(
    val id: Int,
    var x: Float,
    var y: Float,
    val type: PowerUpType,
    val radius: Float = 16f
)

enum class PowerUpType {
    MULTIBALL,
    WIDE_PADDLE,
    LASER_SHOT,
    BONUS_GEM
}

data class LaserBeam(
    var x: Float,
    var y: Float,
    var vy: Float = -24f
)

@Composable
fun BrickBreakerGame(
    soundEngine: SoundEngine,
    hapticEngine: HapticEngine,
    crtEnabled: Boolean,
    bestHighScore: Long,
    onScoreFinished: (Long, Int) -> Unit,
    onExitGame: () -> Unit
) {
    val context = LocalContext.current

    var score by remember { mutableLongStateOf(0L) }
    var streak by remember { mutableIntStateOf(1) }
    var fps by remember { mutableIntStateOf(60) }
    var isPaused by remember { mutableStateOf(false) }
    var isGameOver by remember { mutableStateOf(false) }
    var lives by remember { mutableIntStateOf(3) }

    // Game Objects
    val paddleWidthBase = 220f
    var paddleWidth by remember { mutableStateOf(paddleWidthBase) }
    val paddleHeight = 24f
    var paddleX by remember { mutableStateOf(500f) }
    var paddleY by remember { mutableStateOf(1500f) }

    val balls = remember { mutableListOf<Ball>() }
    val bricks = remember { mutableListOf<Brick>() }
    val powerUps = remember { mutableListOf<PowerUpDrop>() }
    val lasers = remember { mutableListOf<LaserBeam>() }

    var hasLaserCannon by remember { mutableStateOf(false) }
    var laserTimer by remember { mutableStateOf(0f) }
    var wideTimer by remember { mutableStateOf(0f) }

    val particles = remember { ParticleSystem(250) }
    val floatingTexts = remember { FloatingTextController() }
    val screenShake = remember { ScreenShakeController() }

    var gameWidth by remember { mutableStateOf(1080f) }
    var gameHeight by remember { mutableStateOf(1920f) }
    var isInitialized by remember { mutableStateOf(false) }

    fun initBricks(w: Float, h: Float) {
        bricks.clear()
        val cols = 7
        val rows = 5
        val padding = 16f
        val topOffset = h * 0.15f
        val brickW = (w - (cols + 1) * padding) / cols
        val brickH = 46f

        val palette = listOf(HotMagenta, NeonCyan, LiquidGold, MatrixGreen, SolarOrange)

        var id = 0
        for (r in 0 until rows) {
            val color = palette[r % palette.size]
            val hp = if (r == 0) 2 else 1
            for (c in 0 until cols) {
                val bx = padding + c * (brickW + padding)
                val by = topOffset + r * (brickH + padding)
                val hasBonus = (id % 5 == 0)
                bricks.add(
                    Brick(
                        id = id++,
                        x = bx,
                        y = by,
                        width = brickW,
                        height = brickH,
                        color = color,
                        hp = hp,
                        maxHp = hp,
                        points = 100 * hp,
                        hasPowerUp = hasBonus
                    )
                )
            }
        }
    }

    fun resetGame() {
        score = 0L
        streak = 1
        lives = 3
        isGameOver = false
        isPaused = false
        hasLaserCannon = false
        paddleWidth = paddleWidthBase
        powerUps.clear()
        lasers.clear()
        particles.clear()
        floatingTexts.clear()
        screenShake.reset()

        paddleX = gameWidth / 2f
        paddleY = gameHeight * 0.85f

        balls.clear()
        balls.add(
            Ball(
                x = paddleX,
                y = paddleY - 40f,
                vx = if (Random.nextBoolean()) 9f else -9f,
                vy = -14f
            )
        )
        initBricks(gameWidth, gameHeight)
    }

    // 60 FPS Physics & Render Loop
    LaunchedEffect(isPaused, isGameOver, isInitialized) {
        if (!isInitialized || isPaused || isGameOver) return@LaunchedEffect

        var lastNano = System.nanoTime()
        var frameCount = 0
        var fpsTimer = 0f

        while (!isPaused && !isGameOver) {
            withFrameNanos { now ->
                val dt = ((now - lastNano) / 1_000_000_000f).coerceIn(0.001f, 0.033f)
                lastNano = now

                frameCount++
                fpsTimer += dt
                if (fpsTimer >= 0.5f) {
                    fps = (frameCount / fpsTimer).toInt()
                    frameCount = 0
                    fpsTimer = 0f
                }

                screenShake.update(dt)
                particles.update(dt)
                floatingTexts.update(dt)

                // Laser Power-up countdown & autofire
                if (hasLaserCannon) {
                    laserTimer -= dt
                    if (laserTimer <= 0f) {
                        hasLaserCannon = false
                    } else if (Random.nextFloat() < 0.12f) {
                        lasers.add(LaserBeam(x = paddleX - paddleWidth * 0.35f, y = paddleY))
                        lasers.add(LaserBeam(x = paddleX + paddleWidth * 0.35f, y = paddleY))
                        soundEngine.playLaserPing()
                    }
                }

                if (wideTimer > 0f) {
                    wideTimer -= dt
                    if (wideTimer <= 0f) {
                        paddleWidth = paddleWidthBase
                    }
                }

                // Update Lasers
                val laserIter = lasers.iterator()
                while (laserIter.hasNext()) {
                    val l = laserIter.next()
                    l.y += l.vy
                    if (l.y < 0) {
                        laserIter.remove()
                        continue
                    }
                    // Check laser brick collision
                    for (b in bricks) {
                        if (b.hp > 0 && l.x >= b.x && l.x <= b.x + b.width && l.y >= b.y && l.y <= b.y + b.height) {
                            b.hp--
                            laserIter.remove()
                            particles.burst(l.x, l.y, 8, listOf(NeonCyan, Color.White))
                            if (b.hp <= 0) {
                                score += b.points
                                soundEngine.playBrickBreak()
                                hapticEngine.tap(context)
                                floatingTexts.spawn("+${b.points}", b.x + b.width / 2, b.y, b.color)
                            }
                            break
                        }
                    }
                }

                // Update Falling Power-ups
                val pIter = powerUps.iterator()
                while (pIter.hasNext()) {
                    val pu = pIter.next()
                    pu.y += 5.5f
                    // Check paddle catch
                    if (pu.y >= paddleY - paddleHeight / 2 && pu.y <= paddleY + paddleHeight &&
                        pu.x >= paddleX - paddleWidth / 2 && pu.x <= paddleX + paddleWidth / 2
                    ) {
                        pIter.remove()
                        soundEngine.playPowerUp()
                        hapticEngine.doublePulse(context)
                        floatingTexts.spawn("POWER UP!", paddleX, paddleY - 30f, LiquidGold, 46f)
                        when (pu.type) {
                            PowerUpType.MULTIBALL -> {
                                if (balls.isNotEmpty()) {
                                    val b = balls.first()
                                    balls.add(Ball(b.x, b.y, b.vx * 0.9f - 4f, -abs(b.vy)))
                                    balls.add(Ball(b.x, b.y, b.vx * 0.9f + 4f, -abs(b.vy)))
                                }
                            }
                            PowerUpType.WIDE_PADDLE -> {
                                paddleWidth = paddleWidthBase * 1.55f
                                wideTimer = 9f
                            }
                            PowerUpType.LASER_SHOT -> {
                                hasLaserCannon = true
                                laserTimer = 8f
                            }
                            PowerUpType.BONUS_GEM -> {
                                score += 500
                                floatingTexts.spawn("+500 GEMS", paddleX, paddleY - 60f, LiquidGold)
                            }
                        }
                        particles.burst(pu.x, pu.y, 16, listOf(LiquidGold, NeonCyan, Color.White))
                    } else if (pu.y > gameHeight) {
                        pIter.remove()
                    }
                }

                // Update Balls
                val ballIter = balls.iterator()
                while (ballIter.hasNext()) {
                    val ball = ballIter.next()

                    // Trail update
                    ball.trail.add(0, Offset(ball.x, ball.y))
                    if (ball.trail.size > 8) ball.trail.removeAt(ball.trail.size - 1)

                    ball.x += ball.vx
                    ball.y += ball.vy

                    // Wall collision
                    if (ball.x <= ball.radius) {
                        ball.x = ball.radius
                        ball.vx = abs(ball.vx)
                        soundEngine.playLaserPing()
                    } else if (ball.x >= gameWidth - ball.radius) {
                        ball.x = gameWidth - ball.radius
                        ball.vx = -abs(ball.vx)
                        soundEngine.playLaserPing()
                    }
                    if (ball.y <= ball.radius + 60f) {
                        ball.y = ball.radius + 60f
                        ball.vy = abs(ball.vy)
                        soundEngine.playLaserPing()
                    }

                    // Paddle Rebound with variable strike angle
                    val padTop = paddleY - paddleHeight / 2
                    val padBottom = paddleY + paddleHeight / 2
                    val padLeft = paddleX - paddleWidth / 2
                    val padRight = paddleX + paddleWidth / 2

                    if (ball.vy > 0 && ball.y + ball.radius >= padTop && ball.y - ball.radius <= padBottom &&
                        ball.x >= padLeft - 10f && ball.x <= padRight + 10f
                    ) {
                        ball.y = padTop - ball.radius
                        // Rebound calculation: -1 (far left) to +1 (far right)
                        val hitOffset = ((ball.x - paddleX) / (paddleWidth / 2f)).coerceIn(-1f, 1f)
                        val speed = 16f
                        ball.vx = hitOffset * 13f
                        ball.vy = -speed

                        soundEngine.playBassThump()
                        hapticEngine.tap(context)
                        screenShake.addTrauma(0.12f)
                        particles.burst(ball.x, padTop, 10, listOf(NeonCyan, Color.White), minSpeed = 3f, maxSpeed = 7f)
                    }

                    // Brick Collision
                    for (b in bricks) {
                        if (b.hp <= 0) continue
                        if (ball.x + ball.radius >= b.x && ball.x - ball.radius <= b.x + b.width &&
                            ball.y + ball.radius >= b.y && ball.y - ball.radius <= b.y + b.height
                        ) {
                            // Rebound ball
                            ball.vy = -ball.vy
                            b.hp--
                            screenShake.addTrauma(0.18f)

                            if (b.hp <= 0) {
                                score += b.points * streak
                                streak++
                                soundEngine.playBrickBreak()
                                hapticEngine.impact(context)
                                floatingTexts.spawn("+${b.points * streak}", b.x + b.width / 2, b.y, b.color)
                                particles.burst(
                                    b.x + b.width / 2,
                                    b.y + b.height / 2,
                                    18,
                                    listOf(b.color, NeonCyan, Color.White)
                                )

                                if (b.hasPowerUp) {
                                    val types = PowerUpType.values()
                                    val chosen = types[Random.nextInt(types.size)]
                                    powerUps.add(PowerUpDrop(Random.nextInt(), b.x + b.width / 2, b.y + b.height / 2, chosen))
                                }
                            } else {
                                soundEngine.playLaserPing()
                                particles.burst(ball.x, ball.y, 6, listOf(b.color))
                            }
                            break
                        }
                    }

                    // Bottom drop (Loss of ball)
                    if (ball.y > gameHeight + 50f) {
                        ballIter.remove()
                    }
                }

                // Check if all balls lost
                if (balls.isEmpty()) {
                    lives--
                    streak = 1
                    screenShake.addTrauma(0.45f)
                    hapticEngine.heavyShockwave(context)

                    if (lives > 0) {
                        soundEngine.playBassThump()
                        balls.add(
                            Ball(
                                x = paddleX,
                                y = paddleY - 40f,
                                vx = if (Random.nextBoolean()) 8f else -8f,
                                vy = -14f
                            )
                        )
                    } else {
                        // Game Over
                        isGameOver = true
                        soundEngine.playGameOverChord()
                        onScoreFinished(score, streak)
                    }
                }

                // If all bricks destroyed, regenerate next wave with bonus!
                if (bricks.none { it.hp > 0 }) {
                    score += 2500
                    streak += 2
                    soundEngine.playPowerUp()
                    floatingTexts.spawn("WAVE CLEARED! +2500", gameWidth / 2f, gameHeight * 0.4f, LiquidGold, 48f)
                    initBricks(gameWidth, gameHeight)
                }
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberDark)
            .pointerInput(Unit) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    paddleX = (paddleX + dragAmount.x).coerceIn(paddleWidth / 2, gameWidth - paddleWidth / 2)
                }
            }
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            if (!isInitialized) {
                gameWidth = size.width
                gameHeight = size.height
                resetGame()
                isInitialized = true
            }

            val shake = screenShake.getOffset()

            // Draw Background Cyber Matrix Grid
            val gridStep = 60f
            for (x in 0..(size.width / gridStep).toInt()) {
                drawLine(
                    color = Color(0x0800F0FF),
                    start = Offset(x * gridStep + shake.x, 0f),
                    end = Offset(x * gridStep + shake.x, size.height),
                    strokeWidth = 1f
                )
            }
            for (y in 0..(size.height / gridStep).toInt()) {
                drawLine(
                    color = Color(0x0800F0FF),
                    start = Offset(0f, y * gridStep + shake.y),
                    end = Offset(size.width, y * gridStep + shake.y),
                    strokeWidth = 1f
                )
            }

            // Draw Bricks
            for (b in bricks) {
                if (b.hp <= 0) continue
                val brickColor = if (b.hp > 1) b.color else b.color.copy(alpha = 0.85f)
                // Ambient glow behind brick
                drawRoundRect(
                    color = brickColor.copy(alpha = 0.3f),
                    topLeft = Offset(b.x - 3f + shake.x, b.y - 3f + shake.y),
                    size = Size(b.width + 6f, b.height + 6f),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(10f, 10f)
                )
                // Solid brick body
                drawRoundRect(
                    brush = Brush.verticalGradient(listOf(brickColor, brickColor.copy(alpha = 0.7f))),
                    topLeft = Offset(b.x + shake.x, b.y + shake.y),
                    size = Size(b.width, b.height),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(8f, 8f)
                )
                // Highlighting top edge
                drawLine(
                    color = Color.White.copy(alpha = 0.65f),
                    start = Offset(b.x + 8f + shake.x, b.y + 3f + shake.y),
                    end = Offset(b.x + b.width - 8f + shake.x, b.y + 3f + shake.y),
                    strokeWidth = 2.5f
                )
            }

            // Draw Lasers
            for (l in lasers) {
                drawLine(
                    color = LaserRed,
                    start = Offset(l.x + shake.x, l.y + shake.y),
                    end = Offset(l.x + shake.x, l.y + 24f + shake.y),
                    strokeWidth = 5f
                )
                drawCircle(
                    color = Color.White,
                    radius = 4f,
                    center = Offset(l.x + shake.x, l.y + shake.y)
                )
            }

            // Draw Power-ups
            for (pu in powerUps) {
                val puColor = when (pu.type) {
                    PowerUpType.MULTIBALL -> NeonCyan
                    PowerUpType.WIDE_PADDLE -> MatrixGreen
                    PowerUpType.LASER_SHOT -> LaserRed
                    PowerUpType.BONUS_GEM -> LiquidGold
                }
                drawCircle(color = puColor.copy(alpha = 0.4f), radius = pu.radius * 1.5f, center = Offset(pu.x + shake.x, pu.y + shake.y))
                drawCircle(color = puColor, radius = pu.radius, center = Offset(pu.x + shake.x, pu.y + shake.y))
                drawCircle(color = Color.White, radius = pu.radius * 0.45f, center = Offset(pu.x + shake.x, pu.y + shake.y))
            }

            // Draw Ball Trails & Balls
            for (ball in balls) {
                for (i in ball.trail.indices) {
                    val pos = ball.trail[i]
                    val alpha = (1f - (i.toFloat() / ball.trail.size)) * 0.45f
                    drawCircle(
                        color = NeonCyan.copy(alpha = alpha),
                        radius = ball.radius * (1f - (i * 0.08f)),
                        center = Offset(pos.x + shake.x, pos.y + shake.y)
                    )
                }
                // Glowing outer aura
                drawCircle(
                    color = NeonCyan.copy(alpha = 0.45f),
                    radius = ball.radius * 1.8f,
                    center = Offset(ball.x + shake.x, ball.y + shake.y)
                )
                // Core ball
                drawCircle(
                    color = Color.White,
                    radius = ball.radius,
                    center = Offset(ball.x + shake.x, ball.y + shake.y)
                )
            }

            // Draw Paddle
            val padLeft = paddleX - paddleWidth / 2f + shake.x
            val padTop = paddleY - paddleHeight / 2f + shake.y
            // Paddle Glow
            drawRoundRect(
                color = NeonCyan.copy(alpha = 0.35f),
                topLeft = Offset(padLeft - 4f, padTop - 4f),
                size = Size(paddleWidth + 8f, paddleHeight + 8f),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(14f, 14f)
            )
            // Paddle Base
            drawRoundRect(
                brush = Brush.horizontalGradient(listOf(NeonCyan, HotMagenta, NeonCyan)),
                topLeft = Offset(padLeft, padTop),
                size = Size(paddleWidth, paddleHeight),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(12f, 12f)
            )
            // Paddle Core Line
            drawLine(
                color = Color.White,
                start = Offset(padLeft + 12f, padTop + paddleHeight / 2),
                end = Offset(padLeft + paddleWidth - 12f, padTop + paddleHeight / 2),
                strokeWidth = 2.5f
            )

            // Render Particle Engine & Floating Scores
            particles.render(this)
            floatingTexts.render(this)
        }

        // CRT Scanline Overlay
        CrtScanlinesOverlay(enabled = crtEnabled)

        // Top HUD
        GameHudHeader(
            gameTitle = "BRICK BREAKER DX",
            score = score,
            fps = fps,
            streak = streak,
            accentColor = NeonCyan,
            onPauseClick = { isPaused = true },
            modifier = Modifier.statusBarsPadding()
        )

        // Pause Menu
        GamePauseDialog(
            isOpen = isPaused,
            gameTitle = "Neon Brick Breaker DX",
            score = score,
            onResume = { isPaused = false },
            onRestart = { resetGame() },
            onExit = onExitGame,
            isSoundOn = soundEngine.isSoundEnabled.value,
            onToggleSound = { soundEngine.setSoundEnabled(!soundEngine.isSoundEnabled.value) }
        )

        // Game Over Menu
        GameOverDialog(
            isOpen = isGameOver,
            gameTitle = "Neon Brick Breaker DX",
            score = score,
            highScore = maxOf(bestHighScore, score),
            isNewHighScore = score > bestHighScore,
            coinsEarned = (score / 10).coerceAtLeast(5),
            onRestart = { resetGame() },
            onExit = onExitGame
        )
    }
}
