package com.example.games.gravitydash

import android.content.Context
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import com.example.engine.audio.SoundEngine
import com.example.engine.fx.FloatingTextController
import com.example.engine.fx.ParticleSystem
import com.example.engine.fx.ScreenShakeController
import com.example.engine.haptics.HapticEngine
import com.example.ui.components.CrtScanlinesOverlay
import com.example.ui.components.GameHudHeader
import com.example.ui.components.GameOverDialog
import com.example.ui.components.GamePauseDialog
import com.example.ui.theme.CyberDark
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.HotMagenta
import com.example.ui.theme.LaserRed
import com.example.ui.theme.LiquidGold
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.SolarOrange
import kotlin.math.hypot
import kotlin.random.Random

data class NeonPillar(
    val id: Int,
    var x: Float,
    val width: Float = 75f,
    val topHeight: Float,
    val bottomHeight: Float,
    var passed: Boolean = false
)

data class EnergyCrystal(
    val id: Int,
    var x: Float,
    var y: Float,
    val radius: Float = 14f,
    var collected: Boolean = false
)

data class GhostPosition(val x: Float, val y: Float, val alpha: Float)

@Composable
fun GravityDashGame(
    soundEngine: SoundEngine,
    hapticEngine: HapticEngine,
    crtEnabled: Boolean,
    bestHighScore: Long,
    onScoreFinished: (Long, Int) -> Unit,
    onExitGame: () -> Unit
) {
    val context = LocalContext.current

    var score by remember { mutableLongStateOf(0L) }
    var streak by remember { mutableIntStateOf(1) }
    var fps by remember { mutableIntStateOf(60) }
    var isPaused by remember { mutableStateOf(false) }
    var isGameOver by remember { mutableStateOf(false) }

    // Runner Avatar State
    val avatarSize = 34f
    var avatarX by remember { mutableStateOf(240f) }
    var avatarY by remember { mutableStateOf(500f) }
    var velocityY by remember { mutableStateOf(0f) }
    var gravityDirection by remember { mutableStateOf(1) } // +1 = down, -1 = up
    val gravityMagnitude = 36f

    // Visual FX after-image ghost list
    val ghostHistory = remember { mutableListOf<GhostPosition>() }

    // Procedural Obstacles
    val pillars = remember { mutableListOf<NeonPillar>() }
    val crystals = remember { mutableListOf<EnergyCrystal>() }

    val particles = remember { ParticleSystem(220) }
    val floatingTexts = remember { FloatingTextController() }
    val screenShake = remember { ScreenShakeController() }

    var gameWidth by remember { mutableStateOf(1080f) }
    var gameHeight by remember { mutableStateOf(1920f) }
    var isInitialized by remember { mutableStateOf(false) }
    var scrollSpeed by remember { mutableStateOf(8.5f) }

    fun spawnPillar(startX: Float, h: Float) {
        val gap = 340f
        val ceilingMargin = 120f
        val floorMargin = 100f
        val availableHeight = h - ceilingMargin - floorMargin - gap
        val topH = ceilingMargin + Random.nextFloat() * availableHeight
        val botH = h - floorMargin - (topH + gap)

        val pId = Random.nextInt()
        pillars.add(NeonPillar(id = pId, x = startX, topHeight = topH, bottomHeight = botH))

        // Spawn bonus crystal in the center of gap
        if (Random.nextFloat() < 0.65f) {
            crystals.add(EnergyCrystal(id = pId, x = startX + 35f, y = topH + gap / 2f))
        }
    }

    fun resetGame() {
        score = 0L
        streak = 1
        scrollSpeed = 8.5f
        gravityDirection = 1
        velocityY = 0f
        avatarX = 240f
        avatarY = gameHeight * 0.45f
        isGameOver = false
        isPaused = false
        pillars.clear()
        crystals.clear()
        ghostHistory.clear()
        particles.clear()
        floatingTexts.clear()
        screenShake.reset()

        var nextX = gameWidth + 200f
        for (i in 0 until 5) {
            spawnPillar(nextX, gameHeight)
            nextX += 380f
        }
    }

    fun flipGravity() {
        if (isPaused || isGameOver) return
        gravityDirection *= -1
        velocityY = gravityDirection * 6f
        soundEngine.playGravityFlip()
        hapticEngine.tap(context)
        screenShake.addTrauma(0.12f)
        particles.burst(
            avatarX,
            avatarY,
            14,
            listOf(HotMagenta, NeonCyan, Color.White),
            minSpeed = 4f,
            maxSpeed = 10f
        )
    }

    LaunchedEffect(isPaused, isGameOver, isInitialized) {
        if (!isInitialized || isPaused || isGameOver) return@LaunchedEffect

        var lastNano = System.nanoTime()
        var frameCount = 0
        var fpsTimer = 0f

        while (!isPaused && !isGameOver) {
            withFrameNanos { now ->
                val dt = ((now - lastNano) / 1_000_000_000f).coerceIn(0.001f, 0.033f)
                lastNano = now

                frameCount++
                fpsTimer += dt
                if (fpsTimer >= 0.5f) {
                    fps = (frameCount / fpsTimer).toInt()
                    frameCount = 0
                    fpsTimer = 0f
                }

                screenShake.update(dt)
                particles.update(dt)
                floatingTexts.update(dt)

                // Physics update
                velocityY += (gravityDirection * gravityMagnitude) * (dt * 60f)
                avatarY += velocityY * (dt * 60f)

                // Floor / Ceiling Bounds
                val floorY = gameHeight - 110f
                val ceilY = 130f
                if (avatarY > floorY) {
                    avatarY = floorY
                    velocityY = 0f
                } else if (avatarY < ceilY) {
                    avatarY = ceilY
                    velocityY = 0f
                }

                // Jet Exhaust particles & Ghost Trail
                particles.emitJet(
                    x = avatarX - 18f,
                    y = avatarY,
                    color = if (gravityDirection > 0) NeonCyan else HotMagenta,
                    vxOffset = -scrollSpeed * 0.8f
                )

                ghostHistory.add(0, GhostPosition(avatarX, avatarY, 0.65f))
                if (ghostHistory.size > 7) ghostHistory.removeAt(ghostHistory.size - 1)

                // Pillars & Crystals Scrolling
                val pIter = pillars.iterator()
                while (pIter.hasNext()) {
                    val p = pIter.next()
                    p.x -= scrollSpeed

                    // Score pass
                    if (!p.passed && p.x + p.width < avatarX) {
                        p.passed = true
                        val pts = 100 * streak
                        score += pts
                        streak++
                        soundEngine.playScoreChime()
                        floatingTexts.spawn("+$pts", avatarX, avatarY - 35f, NeonCyan)
                    }

                    // Collision Check with top pillar or bottom pillar
                    val hitBoxMargin = 6f
                    val aLeft = avatarX - avatarSize / 2 + hitBoxMargin
                    val aRight = avatarX + avatarSize / 2 - hitBoxMargin
                    val aTop = avatarY - avatarSize / 2 + hitBoxMargin
                    val aBottom = avatarY + avatarSize / 2 - hitBoxMargin

                    val pLeft = p.x
                    val pRight = p.x + p.width
                    val topPillarBottom = p.topHeight
                    val botPillarTop = gameHeight - 100f - p.bottomHeight

                    val collidesTop = (aRight >= pLeft && aLeft <= pRight && aTop <= topPillarBottom)
                    val collidesBot = (aRight >= pLeft && aLeft <= pRight && aBottom >= botPillarTop)

                    if (collidesTop || collidesBot) {
                        isGameOver = true
                        soundEngine.playGameOverChord()
                        hapticEngine.heavyShockwave(context)
                        screenShake.addTrauma(0.65f)
                        particles.burst(avatarX, avatarY, 40, listOf(HotMagenta, SolarOrange, Color.White))
                        onScoreFinished(score, streak)
                        return@withFrameNanos
                    }

                    if (p.x < -p.width - 50f) {
                        pIter.remove()
                    }
                }

                // Crystals Check
                val cIter = crystals.iterator()
                while (cIter.hasNext()) {
                    val c = cIter.next()
                    c.x -= scrollSpeed

                    if (!c.collected && hypot(avatarX - c.x, avatarY - c.y) < avatarSize / 2 + c.radius + 10f) {
                        c.collected = true
                        score += 300
                        soundEngine.playPowerUp()
                        hapticEngine.doublePulse(context)
                        floatingTexts.spawn("+300 CRYSTAL", c.x, c.y - 20f, LiquidGold)
                        particles.burst(c.x, c.y, 22, listOf(LiquidGold, NeonCyan, Color.White))
                    }

                    if (c.x < -50f || c.collected) {
                        cIter.remove()
                    }
                }

                // Spawn new pillars continuously
                val lastPillar = pillars.lastOrNull()
                if (lastPillar != null && lastPillar.x < gameWidth) {
                    spawnPillar(lastPillar.x + 380f, gameHeight)
                }

                // Gradual acceleration
                scrollSpeed = (8.5f + (score / 1500f)).coerceAtMost(14.5f)
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberDark)
            .pointerInput(Unit) {
                detectTapGestures {
                    flipGravity()
                }
            }
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            if (!isInitialized) {
                gameWidth = size.width
                gameHeight = size.height
                resetGame()
                isInitialized = true
            }

            val shake = screenShake.getOffset()

            // Draw Speed Lines in background during high streaks
            if (streak >= 3) {
                val numLines = 6
                for (i in 0 until numLines) {
                    val ly = (i * 260f + (System.currentTimeMillis() % 1000) * 0.4f) % size.height
                    drawLine(
                        color = NeonCyan.copy(alpha = 0.15f),
                        start = Offset(0f, ly + shake.y),
                        end = Offset(size.width, ly + shake.y),
                        strokeWidth = 1.5f
                    )
                }
            }

            // Draw Top and Bottom Neon Boundary Bars
            val ceilY = 130f
            val floorY = size.height - 110f

            // Ceiling line
            drawLine(
                brush = Brush.horizontalGradient(listOf(NeonCyan, HotMagenta, NeonCyan)),
                start = Offset(0f, ceilY + shake.y),
                end = Offset(size.width, ceilY + shake.y),
                strokeWidth = 4f
            )
            // Floor line
            drawLine(
                brush = Brush.horizontalGradient(listOf(HotMagenta, NeonCyan, HotMagenta)),
                start = Offset(0f, floorY + shake.y),
                end = Offset(size.width, floorY + shake.y),
                strokeWidth = 4f
            )

            // Draw Neon Pillars
            for (p in pillars) {
                // Top Pillar
                drawRoundRect(
                    brush = Brush.verticalGradient(listOf(HotMagenta, ElectricPurple)),
                    topLeft = Offset(p.x + shake.x, 0f),
                    size = Size(p.width, p.topHeight + shake.y),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(12f, 12f)
                )
                // Bottom Pillar
                val botY = size.height - 100f - p.bottomHeight
                drawRoundRect(
                    brush = Brush.verticalGradient(listOf(ElectricPurple, HotMagenta)),
                    topLeft = Offset(p.x + shake.x, botY + shake.y),
                    size = Size(p.width, p.bottomHeight),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(12f, 12f)
                )
            }

            // Draw Energy Crystals
            for (c in crystals) {
                if (c.collected) continue
                drawCircle(color = LiquidGold.copy(alpha = 0.4f), radius = c.radius * 2f, center = Offset(c.x + shake.x, c.y + shake.y))
                drawCircle(color = LiquidGold, radius = c.radius, center = Offset(c.x + shake.x, c.y + shake.y))
                drawCircle(color = Color.White, radius = c.radius * 0.4f, center = Offset(c.x + shake.x, c.y + shake.y))
            }

            // Draw Ghost After-Images
            for (i in ghostHistory.indices) {
                val g = ghostHistory[i]
                val alpha = (1f - (i.toFloat() / ghostHistory.size)) * 0.35f
                drawRoundRect(
                    color = NeonCyan.copy(alpha = alpha),
                    topLeft = Offset(g.x - avatarSize / 2 + shake.x, g.y - avatarSize / 2 + shake.y),
                    size = Size(avatarSize, avatarSize),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(8f, 8f)
                )
            }

            // Draw Player Avatar (Cyber Jetpack Runner)
            val avatarColor = if (gravityDirection > 0) NeonCyan else HotMagenta
            drawRoundRect(
                color = avatarColor.copy(alpha = 0.45f),
                topLeft = Offset(avatarX - avatarSize / 2 - 4f + shake.x, avatarY - avatarSize / 2 - 4f + shake.y),
                size = Size(avatarSize + 8f, avatarSize + 8f),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(10f, 10f)
            )
            drawRoundRect(
                brush = Brush.linearGradient(listOf(Color.White, avatarColor)),
                topLeft = Offset(avatarX - avatarSize / 2 + shake.x, avatarY - avatarSize / 2 + shake.y),
                size = Size(avatarSize, avatarSize),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(8f, 8f)
            )

            // Render Particles & Floating Scores
            particles.render(this)
            floatingTexts.render(this)
        }

        // CRT Scanline Overlay
        CrtScanlinesOverlay(enabled = crtEnabled)

        // Top HUD
        GameHudHeader(
            gameTitle = "GRAVITY DASH",
            score = score,
            fps = fps,
            streak = streak,
            accentColor = HotMagenta,
            onPauseClick = { isPaused = true },
            modifier = Modifier.statusBarsPadding()
        )

        // Pause Menu
        GamePauseDialog(
            isOpen = isPaused,
            gameTitle = "Gravity Dash",
            score = score,
            onResume = { isPaused = false },
            onRestart = { resetGame() },
            onExit = onExitGame,
            isSoundOn = soundEngine.isSoundEnabled.value,
            onToggleSound = { soundEngine.setSoundEnabled(!soundEngine.isSoundEnabled.value) }
        )

        // Game Over Menu
        GameOverDialog(
            isOpen = isGameOver,
            gameTitle = "Gravity Dash",
            score = score,
            highScore = maxOf(bestHighScore, score),
            isNewHighScore = score > bestHighScore,
            coinsEarned = (score / 10).coerceAtLeast(5),
            onRestart = { resetGame() },
            onExit = onExitGame
        )
    }
}
