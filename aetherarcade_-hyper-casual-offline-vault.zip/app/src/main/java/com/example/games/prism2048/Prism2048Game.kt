package com.example.games.prism2048

import android.content.Context
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.audio.SoundEngine
import com.example.engine.fx.FloatingTextController
import com.example.engine.fx.ParticleSystem
import com.example.engine.haptics.HapticEngine
import com.example.ui.components.CrtScanlinesOverlay
import com.example.ui.components.GameHudHeader
import com.example.ui.components.GameOverDialog
import com.example.ui.components.GamePauseDialog
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberDark
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceElevated
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.HotMagenta
import com.example.ui.theme.LaserRed
import com.example.ui.theme.LiquidGold
import com.example.ui.theme.MatrixGreen
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonIceBlue
import com.example.ui.theme.SolarOrange
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.random.Random

fun getTileColor(value: Int): Pair<Color, Color> {
    return when (value) {
        2 -> Pair(Color(0xFF1E2D4A), NeonCyan.copy(alpha = 0.8f))
        4 -> Pair(Color(0xFF173859), NeonCyan)
        8 -> Pair(Color(0xFF1F4A63), MatrixGreen)
        16 -> Pair(Color(0xFF265955), MatrixGreen)
        32 -> Pair(Color(0xFF5E4522), SolarOrange)
        64 -> Pair(Color(0xFF703D1A), SolarOrange)
        128 -> Pair(Color(0xFF75273C), HotMagenta)
        256 -> Pair(Color(0xFF8C1D54), HotMagenta)
        512 -> Pair(Color(0xFF6B1D8C), ElectricPurple)
        1024 -> Pair(Color(0xFF43169E), NeonIceBlue)
        2048 -> Pair(Color(0xFF7A650D), LiquidGold)
        else -> Pair(LaserRed.copy(alpha = 0.6f), LiquidGold)
    }
}

@Composable
fun Prism2048Game(
    soundEngine: SoundEngine,
    hapticEngine: HapticEngine,
    crtEnabled: Boolean,
    bestHighScore: Long,
    onScoreFinished: (Long, Int) -> Unit,
    onExitGame: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var board by remember { mutableStateOf(Array(4) { IntArray(4) }) }
    var previousBoard by remember { mutableStateOf<Array<IntArray>?>(null) }
    var previousScore by remember { mutableLongStateOf(0L) }

    var score by remember { mutableLongStateOf(0L) }
    var highestTile by remember { mutableIntStateOf(2) }
    var isPaused by remember { mutableStateOf(false) }
    var isGameOver by remember { mutableStateOf(false) }

    val particles = remember { ParticleSystem(220) }
    val floatingTexts = remember { FloatingTextController() }

    fun addRandomTile(targetBoard: Array<IntArray>): Boolean {
        val emptySlots = mutableListOf<Pair<Int, Int>>()
        for (r in 0 until 4) {
            for (c in 0 until 4) {
                if (targetBoard[r][c] == 0) emptySlots.add(Pair(r, c))
            }
        }
        if (emptySlots.isEmpty()) return false
        val (r, c) = emptySlots[Random.nextInt(emptySlots.size)]
        targetBoard[r][c] = if (Random.nextFloat() < 0.9f) 2 else 4
        return true
    }

    fun canMove(b: Array<IntArray>): Boolean {
        for (r in 0 until 4) {
            for (c in 0 until 4) {
                if (b[r][c] == 0) return true
                if (c < 3 && b[r][c] == b[r][c + 1]) return true
                if (r < 3 && b[r][c] == b[r + 1][c]) return true
            }
        }
        return false
    }

    fun resetGame() {
        val newBoard = Array(4) { IntArray(4) }
        addRandomTile(newBoard)
        addRandomTile(newBoard)
        board = newBoard
        previousBoard = null
        score = 0L
        previousScore = 0L
        highestTile = 2
        isGameOver = false
        isPaused = false
        particles.clear()
        floatingTexts.clear()
    }

    LaunchedEffect(Unit) {
        resetGame()
    }

    fun move(dirX: Int, dirY: Int) {
        if (isGameOver || isPaused) return

        // Deep copy for undo
        val clone = Array(4) { r -> board[r].clone() }
        var moved = false
        var pointsGained = 0L
        val newBoard = Array(4) { r -> board[r].clone() }

        if (dirX != 0) {
            // Horizontal move
            for (r in 0 until 4) {
                val row = mutableListOf<Int>()
                for (c in 0 until 4) {
                    if (newBoard[r][c] != 0) row.add(newBoard[r][c])
                }
                if (dirX > 0) row.reverse()

                val merged = mutableListOf<Int>()
                var i = 0
                while (i < row.size) {
                    if (i + 1 < row.size && row[i] == row[i + 1]) {
                        val v = row[i] * 2
                        merged.add(v)
                        pointsGained += v
                        highestTile = maxOf(highestTile, v)
                        i += 2
                    } else {
                        merged.add(row[i])
                        i++
                    }
                }
                while (merged.size < 4) merged.add(0)
                if (dirX > 0) merged.reverse()

                for (c in 0 until 4) {
                    if (newBoard[r][c] != merged[c]) moved = true
                    newBoard[r][c] = merged[c]
                }
            }
        } else if (dirY != 0) {
            // Vertical move
            for (c in 0 until 4) {
                val col = mutableListOf<Int>()
                for (r in 0 until 4) {
                    if (newBoard[r][c] != 0) col.add(newBoard[r][c])
                }
                if (dirY > 0) col.reverse()

                val merged = mutableListOf<Int>()
                var i = 0
                while (i < col.size) {
                    if (i + 1 < col.size && col[i] == col[i + 1]) {
                        val v = col[i] * 2
                        merged.add(v)
                        pointsGained += v
                        highestTile = maxOf(highestTile, v)
                        i += 2
                    } else {
                        merged.add(col[i])
                        i++
                    }
                }
                while (merged.size < 4) merged.add(0)
                if (dirY > 0) merged.reverse()

                for (r in 0 until 4) {
                    if (newBoard[r][c] != merged[r]) moved = true
                    newBoard[r][c] = merged[r]
                }
            }
        }

        if (moved) {
            previousBoard = clone
            previousScore = score
            score += pointsGained

            if (pointsGained > 0) {
                val tier = (highestTile / 64).coerceIn(1, 10)
                soundEngine.playMergeChime(tier)
                if (pointsGained >= 128) {
                    hapticEngine.doublePulse(context)
                } else {
                    hapticEngine.tap(context)
                }
            } else {
                soundEngine.playTactileBlip()
                hapticEngine.tap(context)
            }

            addRandomTile(newBoard)
            board = newBoard

            if (!canMove(newBoard)) {
                isGameOver = true
                soundEngine.playGameOverChord()
                hapticEngine.heavyShockwave(context)
                onScoreFinished(score, 1)
            }
        }
    }

    fun undoMove() {
        val prev = previousBoard ?: return
        board = prev
        score = previousScore
        previousBoard = null
        soundEngine.playTactileBlip()
        hapticEngine.tap(context)
    }

    var totalDragX by remember { mutableStateOf(0f) }
    var totalDragY by remember { mutableStateOf(0f) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberDark)
            .statusBarsPadding()
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = {
                        totalDragX = 0f
                        totalDragY = 0f
                    },
                    onDrag = { change, dragAmount ->
                        change.consume()
                        totalDragX += dragAmount.x
                        totalDragY += dragAmount.y
                    },
                    onDragEnd = {
                        val threshold = 55f
                        if (abs(totalDragX) > abs(totalDragY)) {
                            if (abs(totalDragX) > threshold) {
                                move(if (totalDragX > 0) 1 else -1, 0)
                            }
                        } else {
                            if (abs(totalDragY) > threshold) {
                                move(0, if (totalDragY > 0) 1 else -1)
                            }
                        }
                    }
                )
            }
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Header
            GameHudHeader(
                gameTitle = "2048 PRISM GLOW",
                score = score,
                fps = 60,
                streak = 1,
                accentColor = LiquidGold,
                onPauseClick = { isPaused = true }
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Sub-bar with Highest Tile and Undo/Restart actions
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = CyberSurfaceElevated,
                    border = BorderStroke(1.dp, CyberBorder)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(text = "TOP TILE:", color = TextTertiary, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                        Text(text = "$highestTile", color = LiquidGold, fontSize = 14.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    IconButton(
                        onClick = { undoMove() },
                        enabled = previousBoard != null,
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(CyberSurfaceElevated)
                            .border(1.dp, CyberBorder, RoundedCornerShape(10.dp))
                    ) {
                        Icon(
                            imageVector = Icons.Default.Undo,
                            contentDescription = "Undo Move",
                            tint = if (previousBoard != null) NeonCyan else TextTertiary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    IconButton(
                        onClick = { resetGame() },
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(CyberSurfaceElevated)
                            .border(1.dp, CyberBorder, RoundedCornerShape(10.dp))
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Reset Board",
                            tint = HotMagenta,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // The 4x4 Grid Board
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f)
                    .clip(RoundedCornerShape(22.dp))
                    .background(CyberSurface.copy(alpha = 0.85f))
                    .border(BorderStroke(1.5.dp, CyberBorder.copy(alpha = 0.7f)), RoundedCornerShape(22.dp))
                    .padding(12.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    for (r in 0 until 4) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            for (c in 0 until 4) {
                                val value = board[r][c]
                                TileView(
                                    value = value,
                                    modifier = Modifier
                                        .weight(1f)
                                        .fillMaxSize()
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))
            Text(
                text = "SWIPE TO MERGE MATCHING TILES",
                color = TextTertiary,
                fontSize = 11.sp,
                letterSpacing = 1.sp,
                fontFamily = FontFamily.Monospace
            )
        }

        CrtScanlinesOverlay(enabled = crtEnabled)

        // Pause Menu
        GamePauseDialog(
            isOpen = isPaused,
            gameTitle = "2048 Prism Glow",
            score = score,
            onResume = { isPaused = false },
            onRestart = { resetGame() },
            onExit = onExitGame,
            isSoundOn = soundEngine.isSoundEnabled.value,
            onToggleSound = { soundEngine.setSoundEnabled(!soundEngine.isSoundEnabled.value) }
        )

        // Game Over Menu
        GameOverDialog(
            isOpen = isGameOver,
            gameTitle = "2048 Prism Glow",
            score = score,
            highScore = maxOf(bestHighScore, score),
            isNewHighScore = score > bestHighScore,
            coinsEarned = (score / 15).coerceAtLeast(5),
            onRestart = { resetGame() },
            onExit = onExitGame
        )
    }
}

@Composable
fun TileView(value: Int, modifier: Modifier = Modifier) {
    if (value == 0) {
        Box(
            modifier = modifier
                .clip(RoundedCornerShape(12.dp))
                .background(CyberDark.copy(alpha = 0.45f))
                .border(0.5.dp, CyberBorder.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
        )
    } else {
        val (bgColor, accentColor) = getTileColor(value)
        val isHighTier = value >= 512

        Box(
            modifier = modifier
                .clip(RoundedCornerShape(12.dp))
                .background(bgColor)
                .border(
                    BorderStroke(
                        width = if (isHighTier) 2.dp else 1.dp,
                        color = accentColor.copy(alpha = if (isHighTier) 0.9f else 0.5f)
                    ),
                    shape = RoundedCornerShape(12.dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            val fontSize = when {
                value >= 1024 -> 18.sp
                value >= 128 -> 22.sp
                else -> 26.sp
            }

            Text(
                text = "$value",
                color = if (isHighTier) LiquidGold else Color.White,
                fontSize = fontSize,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}
