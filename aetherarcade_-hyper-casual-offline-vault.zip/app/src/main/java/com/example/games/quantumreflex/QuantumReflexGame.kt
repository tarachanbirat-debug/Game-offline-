package com.example.games.quantumreflex

import android.content.Context
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import com.example.engine.audio.SoundEngine
import com.example.engine.fx.FloatingTextController
import com.example.engine.fx.ParticleSystem
import com.example.engine.fx.ScreenShakeController
import com.example.engine.haptics.HapticEngine
import com.example.ui.components.CrtScanlinesOverlay
import com.example.ui.components.GameHudHeader
import com.example.ui.components.GameOverDialog
import com.example.ui.components.GamePauseDialog
import com.example.ui.theme.CyberDark
import com.example.ui.theme.HotMagenta
import com.example.ui.theme.LiquidGold
import com.example.ui.theme.MatrixGreen
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.SolarOrange
import kotlin.math.abs
import kotlin.random.Random

data class ContractingRing(
    val id: Int,
    var radius: Float,
    val initialRadius: Float,
    val speed: Float,
    val color: Color
)

@Composable
fun QuantumReflexGame(
    soundEngine: SoundEngine,
    hapticEngine: HapticEngine,
    crtEnabled: Boolean,
    bestHighScore: Long,
    onScoreFinished: (Long, Int) -> Unit,
    onExitGame: () -> Unit
) {
    val context = LocalContext.current

    var score by remember { mutableLongStateOf(0L) }
    var streak by remember { mutableIntStateOf(1) }
    var fps by remember { mutableIntStateOf(60) }
    var lives by remember { mutableIntStateOf(3) }
    var isPaused by remember { mutableStateOf(false) }
    var isGameOver by remember { mutableStateOf(false) }

    val targetRadius = 140f
    val tolerance = 32f

    val rings = remember { mutableListOf<ContractingRing>() }
    val particles = remember { ParticleSystem(220) }
    val floatingTexts = remember { FloatingTextController() }
    val screenShake = remember { ScreenShakeController() }

    var gameWidth by remember { mutableStateOf(1080f) }
    var gameHeight by remember { mutableStateOf(1920f) }
    var isInitialized by remember { mutableStateOf(false) }
    var spawnCooldown by remember { mutableStateOf(1.2f) }

    val palette = listOf(NeonCyan, HotMagenta, MatrixGreen, LiquidGold)

    fun resetGame() {
        score = 0L
        streak = 1
        lives = 3
        isGameOver = false
        isPaused = false
        rings.clear()
        particles.clear()
        floatingTexts.clear()
        screenShake.reset()
        spawnCooldown = 1.2f
    }

    fun handleTap() {
        if (isGameOver || isPaused) return
        val center = Offset(gameWidth / 2f, gameHeight / 2f)

        if (rings.isEmpty()) {
            soundEngine.playTactileBlip()
            return
        }

        // Find ring closest to targetRadius
        var closestRing: ContractingRing? = null
        var minDiff = Float.MAX_VALUE
        for (r in rings) {
            val diff = abs(r.radius - targetRadius)
            if (diff < minDiff) {
                minDiff = diff
                closestRing = r
            }
        }

        if (closestRing != null && minDiff <= tolerance) {
            // Hit!
            rings.remove(closestRing)
            val isPerfect = minDiff <= 12f
            val basePts = if (isPerfect) 250 else 100
            val pts = basePts * streak
            score += pts
            streak++

            if (isPerfect) {
                soundEngine.playPowerUp()
                hapticEngine.doublePulse(context)
                screenShake.addTrauma(0.18f)
                floatingTexts.spawn("PERFECT! +$pts", center.x, center.y - targetRadius - 40f, LiquidGold, 46f)
            } else {
                soundEngine.playScoreChime()
                hapticEngine.tap(context)
                floatingTexts.spawn("GOOD! +$pts", center.x, center.y - targetRadius - 40f, NeonCyan, 40f)
            }

            particles.burst(center.x, center.y, 25, listOf(closestRing.color, Color.White), minSpeed = 5f, maxSpeed = 12f)
        } else {
            // Miss
            streak = 1
            lives--
            soundEngine.playBassThump()
            hapticEngine.impact(context)
            screenShake.addTrauma(0.35f)
            floatingTexts.spawn("MISS!", center.x, center.y, HotMagenta, 42f)

            if (lives <= 0) {
                isGameOver = true
                soundEngine.playGameOverChord()
                onScoreFinished(score, streak)
            }
        }
    }

    LaunchedEffect(isPaused, isGameOver, isInitialized) {
        if (!isInitialized || isPaused || isGameOver) return@LaunchedEffect

        var lastNano = System.nanoTime()
        var frameCount = 0
        var fpsTimer = 0f

        while (!isPaused && !isGameOver) {
            withFrameNanos { now ->
                val dt = ((now - lastNano) / 1_000_000_000f).coerceIn(0.001f, 0.033f)
                lastNano = now

                frameCount++
                fpsTimer += dt
                if (fpsTimer >= 0.5f) {
                    fps = (frameCount / fpsTimer).toInt()
                    frameCount = 0
                    fpsTimer = 0f
                }

                screenShake.update(dt)
                particles.update(dt)
                floatingTexts.update(dt)

                // Spawn Contracting Rings
                spawnCooldown -= dt
                if (spawnCooldown <= 0f) {
                    val color = palette[Random.nextInt(palette.size)]
                    val speed = 220f + (score / 100f).coerceAtMost(280f)
                    rings.add(ContractingRing(id = Random.nextInt(), radius = 550f, initialRadius = 550f, speed = speed, color = color))
                    spawnCooldown = (1.4f - (score / 4000f)).coerceAtLeast(0.65f)
                }

                // Update Rings
                val rIter = rings.iterator()
                while (rIter.hasNext()) {
                    val ring = rIter.next()
                    ring.radius -= ring.speed * dt
                    if (ring.radius < targetRadius - tolerance) {
                        // Ring collapsed past target zone without being tapped -> Miss!
                        rIter.remove()
                        streak = 1
                        lives--
                        soundEngine.playBassThump()
                        hapticEngine.tap(context)
                        screenShake.addTrauma(0.25f)
                        floatingTexts.spawn("MISSED!", gameWidth / 2f, gameHeight / 2f, HotMagenta)

                        if (lives <= 0) {
                            isGameOver = true
                            soundEngine.playGameOverChord()
                            onScoreFinished(score, streak)
                            return@withFrameNanos
                        }
                    }
                }
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberDark)
            .pointerInput(Unit) {
                detectTapGestures {
                    handleTap()
                }
            }
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            if (!isInitialized) {
                gameWidth = size.width
                gameHeight = size.height
                resetGame()
                isInitialized = true
            }

            val center = Offset(size.width / 2f + screenShake.offsetX, size.height / 2f + screenShake.offsetY)

            // Draw Core Target Zone
            // Outer tolerance halo
            drawCircle(
                color = NeonCyan.copy(alpha = 0.08f),
                radius = targetRadius + tolerance,
                center = center
            )
            // Target line ring
            drawCircle(
                color = NeonCyan.copy(alpha = 0.85f),
                radius = targetRadius,
                center = center,
                style = Stroke(width = 3.5f)
            )
            // Inner tolerance boundary
            drawCircle(
                color = NeonCyan.copy(alpha = 0.4f),
                radius = targetRadius - tolerance,
                center = center,
                style = Stroke(width = 1.5f)
            )
            // Center Core Dot
            drawCircle(
                color = LiquidGold,
                radius = 16f,
                center = center
            )

            // Draw Contracting Rings
            for (r in rings) {
                val alpha = (r.radius / r.initialRadius).coerceIn(0.2f, 1f)
                drawCircle(
                    color = r.color.copy(alpha = alpha),
                    radius = r.radius,
                    center = center,
                    style = Stroke(width = 5f)
                )
            }

            // Render FX
            particles.render(this)
            floatingTexts.render(this)
        }

        CrtScanlinesOverlay(enabled = crtEnabled)

        // Top HUD
        GameHudHeader(
            gameTitle = "QUANTUM REFLEX",
            score = score,
            fps = fps,
            streak = streak,
            accentColor = NeonCyan,
            onPauseClick = { isPaused = true },
            modifier = Modifier.statusBarsPadding()
        )

        // Pause Menu
        GamePauseDialog(
            isOpen = isPaused,
            gameTitle = "Quantum Reflex",
            score = score,
            onResume = { isPaused = false },
            onRestart = { resetGame() },
            onExit = onExitGame,
            isSoundOn = soundEngine.isSoundEnabled.value,
            onToggleSound = { soundEngine.setSoundEnabled(!soundEngine.isSoundEnabled.value) }
        )

        // Game Over Menu
        GameOverDialog(
            isOpen = isGameOver,
            gameTitle = "Quantum Reflex",
            score = score,
            highScore = maxOf(bestHighScore, score),
            isNewHighScore = score > bestHighScore,
            coinsEarned = (score / 12).coerceAtLeast(5),
            onRestart = { resetGame() },
            onExit = onExitGame
        )
    }
}
