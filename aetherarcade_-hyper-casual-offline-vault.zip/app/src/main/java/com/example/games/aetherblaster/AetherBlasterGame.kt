package com.example.games.aetherblaster

import android.content.Context
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import com.example.engine.audio.SoundEngine
import com.example.engine.fx.FloatingTextController
import com.example.engine.fx.ParticleSystem
import com.example.engine.fx.ScreenShakeController
import com.example.engine.haptics.HapticEngine
import com.example.ui.components.CrtScanlinesOverlay
import com.example.ui.components.GameHudHeader
import com.example.ui.components.GameOverDialog
import com.example.ui.components.GamePauseDialog
import com.example.ui.theme.CyberDark
import com.example.ui.theme.HotMagenta
import com.example.ui.theme.LiquidGold
import com.example.ui.theme.MatrixGreen
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.SolarOrange
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin
import kotlin.random.Random

data class CyberAsteroid(
    val id: Int,
    var x: Float,
    var y: Float,
    var vx: Float,
    var vy: Float,
    val radius: Float,
    val tier: Int, // 3 = big, 2 = medium, 1 = small
    var rotation: Float = 0f,
    val rotSpeed: Float = 0.02f,
    val color: Color
)

data class BlasterShot(
    var x: Float,
    var y: Float,
    var vx: Float,
    var vy: Float,
    val life: Float = 1.2f,
    var currentLife: Float = 1.2f
)

@Composable
fun AetherBlasterGame(
    soundEngine: SoundEngine,
    hapticEngine: HapticEngine,
    crtEnabled: Boolean,
    bestHighScore: Long,
    onScoreFinished: (Long, Int) -> Unit,
    onExitGame: () -> Unit
) {
    val context = LocalContext.current

    var score by remember { mutableLongStateOf(0L) }
    var streak by remember { mutableIntStateOf(1) }
    var fps by remember { mutableIntStateOf(60) }
    var isPaused by remember { mutableStateOf(false) }
    var isGameOver by remember { mutableStateOf(false) }

    // Ship State
    var shipX by remember { mutableStateOf(500f) }
    var shipY by remember { mutableStateOf(1000f) }
    var shipAngle by remember { mutableStateOf(-Math.PI.toFloat() / 2f) }
    var shipVx by remember { mutableStateOf(0f) }
    var shipVy by remember { mutableStateOf(0f) }

    val asteroids = remember { mutableListOf<CyberAsteroid>() }
    val shots = remember { mutableListOf<BlasterShot>() }

    val particles = remember { ParticleSystem(250) }
    val floatingTexts = remember { FloatingTextController() }
    val screenShake = remember { ScreenShakeController() }

    var gameWidth by remember { mutableStateOf(1080f) }
    var gameHeight by remember { mutableStateOf(1920f) }
    var isInitialized by remember { mutableStateOf(false) }

    fun spawnAsteroid(tier: Int = 3, atX: Float? = null, atY: Float? = null) {
        val radius = when (tier) {
            3 -> 65f
            2 -> 40f
            else -> 24f
        }
        val spawnX = atX ?: if (Random.nextBoolean()) 0f else gameWidth
        val spawnY = atY ?: (Random.nextFloat() * gameHeight)

        val angle = Random.nextFloat() * 2f * Math.PI.toFloat()
        val speed = 2.5f + (4 - tier) * 1.5f

        val colors = listOf(NeonCyan, HotMagenta, MatrixGreen, SolarOrange)
        val color = colors[tier % colors.size]

        asteroids.add(
            CyberAsteroid(
                id = Random.nextInt(),
                x = spawnX,
                y = spawnY,
                vx = cos(angle) * speed,
                vy = sin(angle) * speed,
                radius = radius,
                tier = tier,
                rotation = Random.nextFloat() * 6.28f,
                rotSpeed = (Random.nextFloat() - 0.5f) * 0.04f,
                color = color
            )
        )
    }

    fun fireLaser() {
        val speed = 24f
        val bx = shipX + cos(shipAngle) * 25f
        val by = shipY + sin(shipAngle) * 25f
        shots.add(
            BlasterShot(
                x = bx,
                y = by,
                vx = cos(shipAngle) * speed + shipVx * 0.4f,
                vy = sin(shipAngle) * speed + shipVy * 0.4f
            )
        )
        soundEngine.playLaserPing()
        hapticEngine.tap(context)
        particles.burst(bx, by, 6, listOf(NeonCyan, Color.White), minSpeed = 2f, maxSpeed = 6f)
    }

    fun resetGame() {
        score = 0L
        streak = 1
        shipX = gameWidth / 2f
        shipY = gameHeight / 2f
        shipAngle = -Math.PI.toFloat() / 2f
        shipVx = 0f
        shipVy = 0f
        isGameOver = false
        isPaused = false
        asteroids.clear()
        shots.clear()
        particles.clear()
        floatingTexts.clear()
        screenShake.reset()

        repeat(5) {
            spawnAsteroid(tier = 3)
        }
    }

    LaunchedEffect(isPaused, isGameOver, isInitialized) {
        if (!isInitialized || isPaused || isGameOver) return@LaunchedEffect

        var lastNano = System.nanoTime()
        var frameCount = 0
        var fpsTimer = 0f

        while (!isPaused && !isGameOver) {
            withFrameNanos { now ->
                val dt = ((now - lastNano) / 1_000_000_000f).coerceIn(0.001f, 0.033f)
                lastNano = now

                frameCount++
                fpsTimer += dt
                if (fpsTimer >= 0.5f) {
                    fps = (frameCount / fpsTimer).toInt()
                    frameCount = 0
                    fpsTimer = 0f
                }

                screenShake.update(dt)
                particles.update(dt)
                floatingTexts.update(dt)

                // Ship inertial movement & friction
                shipX += shipVx
                shipY += shipVy
                shipVx *= 0.98f
                shipVy *= 0.98f

                // Screen wrap for ship
                if (shipX < 0) shipX += gameWidth
                if (shipX > gameWidth) shipX -= gameWidth
                if (shipY < 0) shipY += gameHeight
                if (shipY > gameHeight) shipY -= gameHeight

                // Update Shots
                val sIter = shots.iterator()
                while (sIter.hasNext()) {
                    val s = sIter.next()
                    s.x += s.vx
                    s.y += s.vy
                    s.currentLife -= dt
                    if (s.currentLife <= 0f || s.x < 0 || s.x > gameWidth || s.y < 0 || s.y > gameHeight) {
                        sIter.remove()
                        continue
                    }

                    // Check Shot vs Asteroid Collision
                    val aIter = asteroids.iterator()
                    while (aIter.hasNext()) {
                        val a = aIter.next()
                        if (hypot(s.x - a.x, s.y - a.y) < a.radius + 12f) {
                            sIter.remove()
                            aIter.remove()

                            val pts = (4 - a.tier) * 150 * streak
                            score += pts
                            streak++
                            soundEngine.playBrickBreak()
                            hapticEngine.impact(context)
                            screenShake.addTrauma(0.2f)
                            floatingTexts.spawn("+$pts", a.x, a.y, a.color)

                            particles.burst(a.x, a.y, 22, listOf(a.color, Color.White), minSpeed = 4f, maxSpeed = 12f)

                            // Split into smaller asteroids if tier > 1
                            if (a.tier > 1) {
                                spawnAsteroid(tier = a.tier - 1, atX = a.x - 15f, atY = a.y - 15f)
                                spawnAsteroid(tier = a.tier - 1, atX = a.x + 15f, atY = a.y + 15f)
                            }
                            break
                        }
                    }
                }

                // Update Asteroids
                for (a in asteroids) {
                    a.x += a.vx
                    a.y += a.vy
                    a.rotation += a.rotSpeed

                    // Wrap asteroids
                    if (a.x < -a.radius) a.x += gameWidth + a.radius * 2
                    if (a.x > gameWidth + a.radius) a.x -= gameWidth + a.radius * 2
                    if (a.y < -a.radius) a.y += gameHeight + a.radius * 2
                    if (a.y > gameHeight + a.radius) a.y -= gameHeight + a.radius * 2

                    // Ship collision
                    if (hypot(shipX - a.x, shipY - a.y) < a.radius + 18f) {
                        isGameOver = true
                        soundEngine.playGameOverChord()
                        hapticEngine.heavyShockwave(context)
                        screenShake.addTrauma(0.6f)
                        particles.burst(shipX, shipY, 40, listOf(HotMagenta, SolarOrange, Color.White))
                        onScoreFinished(score, streak)
                        return@withFrameNanos
                    }
                }

                // Respawn asteroids if cleared
                if (asteroids.size < 4) {
                    spawnAsteroid(tier = 3)
                }
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberDark)
            .pointerInput(Unit) {
                detectDragGestures(
                    onDrag = { change, dragAmount ->
                        change.consume()
                        shipAngle = atan2(dragAmount.y, dragAmount.x)
                        val speed = 1.2f
                        shipVx += cos(shipAngle) * speed
                        shipVy += sin(shipAngle) * speed

                        // Thruster particles
                        particles.emitJet(
                            x = shipX - cos(shipAngle) * 20f,
                            y = shipY - sin(shipAngle) * 20f,
                            color = HotMagenta,
                            vxOffset = -cos(shipAngle) * 6f
                        )
                    }
                )
            }
            .pointerInput(Unit) {
                detectTapGestures {
                    fireLaser()
                }
            }
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            if (!isInitialized) {
                gameWidth = size.width
                gameHeight = size.height
                resetGame()
                isInitialized = true
            }

            val shake = screenShake.getOffset()

            // Draw Asteroids
            for (a in asteroids) {
                val numSides = 7
                val path = Path()
                for (i in 0 until numSides) {
                    val angle = a.rotation + i * (2f * Math.PI.toFloat() / numSides)
                    val r = a.radius * (0.85f + (i % 2) * 0.3f)
                    val px = a.x + cos(angle) * r + shake.x
                    val py = a.y + sin(angle) * r + shake.y
                    if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
                }
                path.close()
                drawPath(path = path, color = a.color.copy(alpha = 0.85f), style = Stroke(width = 2.5f))
                drawCircle(color = a.color.copy(alpha = 0.2f), radius = a.radius * 1.3f, center = Offset(a.x + shake.x, a.y + shake.y))
            }

            // Draw Lasers
            for (s in shots) {
                drawCircle(color = NeonCyan, radius = 6f, center = Offset(s.x + shake.x, s.y + shake.y))
                drawCircle(color = Color.White, radius = 3f, center = Offset(s.x + shake.x, s.y + shake.y))
            }

            // Draw Vector Ship
            val p1 = Offset(shipX + cos(shipAngle) * 26f + shake.x, shipY + sin(shipAngle) * 26f + shake.y)
            val p2 = Offset(shipX + cos(shipAngle + 2.5f) * 20f + shake.x, shipY + sin(shipAngle + 2.5f) * 20f + shake.y)
            val p3 = Offset(shipX + cos(shipAngle - 2.5f) * 20f + shake.x, shipY + sin(shipAngle - 2.5f) * 20f + shake.y)

            val shipPath = Path().apply {
                moveTo(p1.x, p1.y)
                lineTo(p2.x, p2.y)
                lineTo(shipX + shake.x, shipY + shake.y)
                lineTo(p3.x, p3.y)
                close()
            }
            drawPath(path = shipPath, color = NeonCyan, style = Stroke(width = 3f))
            drawCircle(color = NeonCyan.copy(alpha = 0.3f), radius = 32f, center = Offset(shipX + shake.x, shipY + shake.y))

            // Render FX
            particles.render(this)
            floatingTexts.render(this)
        }

        CrtScanlinesOverlay(enabled = crtEnabled)

        // Top HUD
        GameHudHeader(
            gameTitle = "AETHER BLASTERS",
            score = score,
            fps = fps,
            streak = streak,
            accentColor = NeonCyan,
            onPauseClick = { isPaused = true },
            modifier = Modifier.statusBarsPadding()
        )

        // Pause Menu
        GamePauseDialog(
            isOpen = isPaused,
            gameTitle = "Aether Blasters",
            score = score,
            onResume = { isPaused = false },
            onRestart = { resetGame() },
            onExit = onExitGame,
            isSoundOn = soundEngine.isSoundEnabled.value,
            onToggleSound = { soundEngine.setSoundEnabled(!soundEngine.isSoundEnabled.value) }
        )

        // Game Over Menu
        GameOverDialog(
            isOpen = isGameOver,
            gameTitle = "Aether Blasters",
            score = score,
            highScore = maxOf(bestHighScore, score),
            isNewHighScore = score > bestHighScore,
            coinsEarned = (score / 15).coerceAtLeast(5),
            onRestart = { resetGame() },
            onExit = onExitGame
        )
    }
}
