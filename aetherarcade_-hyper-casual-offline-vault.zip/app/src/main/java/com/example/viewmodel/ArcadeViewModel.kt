package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.GameStatEntity
import com.example.data.TrophyEntity
import com.example.data.VaultDatabase
import com.example.data.VaultProfileEntity
import com.example.data.VaultRepository
import com.example.engine.audio.SoundEngine
import com.example.engine.haptics.HapticEngine
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class VaultTab {
    HUB,
    TROPHIES,
    SOUND_DECK,
    SETTINGS
}

data class ActiveGameInfo(
    val id: String,
    val title: String,
    val category: String
)

class ArcadeViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: VaultRepository = VaultRepository(
        VaultDatabase.getDatabase(application).vaultDao()
    )

    val soundEngine = SoundEngine.instance
    val hapticEngine = HapticEngine.instance

    private val _currentTab = MutableStateFlow(VaultTab.HUB)
    val currentTab: StateFlow<VaultTab> = _currentTab.asStateFlow()

    private val _activeGame = MutableStateFlow<ActiveGameInfo?>(null)
    val activeGame: StateFlow<ActiveGameInfo?> = _activeGame.asStateFlow()

    private val _crtScanlinesEnabled = MutableStateFlow(true)
    val crtScanlinesEnabled: StateFlow<Boolean> = _crtScanlinesEnabled.asStateFlow()

    private val _bloomGlowEnabled = MutableStateFlow(true)
    val bloomGlowEnabled: StateFlow<Boolean> = _bloomGlowEnabled.asStateFlow()

    private val _screenShakeIntensity = MutableStateFlow(1.0f)
    val screenShakeIntensity: StateFlow<Float> = _screenShakeIntensity.asStateFlow()

    private val _selectedCategory = MutableStateFlow("All")
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    val allGameStats: StateFlow<List<GameStatEntity>> = repository.allGameStats
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val profile: StateFlow<VaultProfileEntity?> = repository.profile
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), VaultProfileEntity())

    val trophies: StateFlow<List<TrophyEntity>> = repository.trophies
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        viewModelScope.launch {
            repository.initDefaultDataIfNeeded()
        }
    }

    fun selectTab(tab: VaultTab) {
        soundEngine.playTactileBlip()
        _currentTab.value = tab
    }

    fun launchGame(id: String, title: String, category: String) {
        soundEngine.playPowerUp()
        _activeGame.value = ActiveGameInfo(id, title, category)
    }

    fun exitGameToLobby() {
        soundEngine.playTactileBlip()
        _activeGame.value = null
    }

    fun recordGameScore(gameId: String, title: String, score: Long, streak: Int = 1) {
        viewModelScope.launch {
            repository.recordGameResult(gameId, title, score, streak)
        }
    }

    fun setCategory(category: String) {
        soundEngine.playTactileBlip()
        _selectedCategory.value = category
    }

    fun toggleCrtScanlines() {
        val current = _crtScanlinesEnabled.value
        _crtScanlinesEnabled.value = !current
        viewModelScope.launch {
            profile.value?.let { p ->
                repository.updateProfile(p.copy(crtScanlinesEnabled = !current))
            }
        }
    }

    fun toggleScreenShake() {
        val current = (_screenShakeIntensity.value > 0f)
        val nextVal = if (current) 0f else 1f
        _screenShakeIntensity.value = nextVal
        viewModelScope.launch {
            profile.value?.let { p ->
                repository.updateProfile(p.copy(screenShakeEnabled = !current))
            }
        }
    }

    fun toggleHaptics() {
        val nextVal = !hapticEngine.isHapticsEnabled.value
        hapticEngine.setHapticsEnabled(nextVal)
        viewModelScope.launch {
            profile.value?.let { p ->
                repository.updateProfile(p.copy(hapticsEnabled = nextVal))
            }
        }
    }

    fun toggleSound() {
        val nextVal = !soundEngine.isSoundEnabled.value
        soundEngine.setSoundEnabled(nextVal)
        viewModelScope.launch {
            profile.value?.let { p ->
                repository.updateProfile(p.copy(soundEnabled = nextVal))
            }
        }
    }

    fun toggleBloomGlow() {
        _bloomGlowEnabled.value = !_bloomGlowEnabled.value
    }

    fun setScreenShakeIntensity(intensity: Float) {
        _screenShakeIntensity.value = intensity
    }

    fun resetAllData() {
        viewModelScope.launch {
            repository.resetVaultData()
            repository.initDefaultDataIfNeeded()
        }
    }
}
