package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "game_stats")
data class GameStatEntity(
    @PrimaryKey val gameId: String,
    val gameTitle: String,
    val highScore: Long = 0,
    val playCount: Int = 0,
    val totalScore: Long = 0,
    val bestStreak: Int = 0,
    val lastPlayed: Long = System.currentTimeMillis()
)

@Entity(tableName = "vault_profile")
data class VaultProfileEntity(
    @PrimaryKey val id: Int = 1,
    val playerName: String = "CYBER_PILOT",
    val totalCoins: Long = 450,
    val totalGems: Long = 30,
    val playerLevel: Int = 1,
    val xp: Int = 120,
    val selectedFrame: String = "NEON_CYAN",
    val crtScanlinesEnabled: Boolean = true,
    val screenShakeEnabled: Boolean = true,
    val soundEnabled: Boolean = true,
    val hapticsEnabled: Boolean = true
)

@Entity(tableName = "trophies")
data class TrophyEntity(
    @PrimaryKey val trophyId: String,
    val title: String,
    val description: String,
    val category: String,
    val isUnlocked: Boolean = false,
    val currentProgress: Int = 0,
    val targetProgress: Int = 1,
    val gemReward: Int = 10
)
