package com.example.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull

class VaultRepository(private val vaultDao: VaultDao) {

    val allGameStats: Flow<List<GameStatEntity>> = vaultDao.getAllGameStats()
    val profile: Flow<VaultProfileEntity?> = vaultDao.getProfile()
    val trophies: Flow<List<TrophyEntity>> = vaultDao.getAllTrophies()

    suspend fun recordGameResult(
        gameId: String,
        gameTitle: String,
        score: Long,
        streak: Int = 1
    ) {
        val existing = vaultDao.getGameStat(gameId).firstOrNull()
        val newHigh = if (existing != null) maxOf(existing.highScore, score) else score
        val newPlayCount = (existing?.playCount ?: 0) + 1
        val newTotalScore = (existing?.totalScore ?: 0L) + score
        val newBestStreak = if (existing != null) maxOf(existing.bestStreak, streak) else streak

        vaultDao.insertOrUpdateGameStat(
            GameStatEntity(
                gameId = gameId,
                gameTitle = gameTitle,
                highScore = newHigh,
                playCount = newPlayCount,
                totalScore = newTotalScore,
                bestStreak = newBestStreak,
                lastPlayed = System.currentTimeMillis()
            )
        )

        // Award Coins & Gems based on performance
        val coinsEarned = (score / 10).coerceAtLeast(5L)
        val gemsEarned = if (score > (existing?.highScore ?: 0L)) 5L else 1L

        val curProfile = vaultDao.getProfile().firstOrNull() ?: VaultProfileEntity()
        val newCoins = curProfile.totalCoins + coinsEarned
        val newGems = curProfile.totalGems + gemsEarned
        val newXp = curProfile.xp + (score / 5).toInt().coerceAtLeast(15)
        val newLevel = 1 + (newXp / 300)

        vaultDao.setProfile(
            curProfile.copy(
                totalCoins = newCoins,
                totalGems = newGems,
                xp = newXp,
                playerLevel = newLevel
            )
        )

        checkTrophies(gameId, score, newPlayCount)
    }

    private suspend fun checkTrophies(gameId: String, score: Long, playCount: Int) {
        val trophyList = vaultDao.getAllTrophies().firstOrNull() ?: emptyList()
        for (trophy in trophyList) {
            if (trophy.isUnlocked) continue
            var shouldUnlock = false
            when (trophy.trophyId) {
                "first_play" -> if (playCount >= 1) shouldUnlock = true
                "century_score" -> if (score >= 100) shouldUnlock = true
                "score_1000" -> if (score >= 1000) shouldUnlock = true
                "score_2048" -> if (gameId == "prism_2048" && score >= 2048) shouldUnlock = true
                "brick_master" -> if (gameId == "brick_breaker" && score >= 500) shouldUnlock = true
                "snake_whisperer" -> if (gameId == "cyber_snake" && score >= 400) shouldUnlock = true
                "gravity_defier" -> if (gameId == "gravity_dash" && score >= 30) shouldUnlock = true
            }
            if (shouldUnlock) {
                vaultDao.updateTrophy(trophy.copy(isUnlocked = true, currentProgress = trophy.targetProgress))
                val curProfile = vaultDao.getProfile().firstOrNull() ?: VaultProfileEntity()
                vaultDao.setProfile(curProfile.copy(totalGems = curProfile.totalGems + trophy.gemReward))
            }
        }
    }

    suspend fun initDefaultDataIfNeeded() {
        val curProfile = vaultDao.getProfile().firstOrNull()
        if (curProfile == null) {
            vaultDao.setProfile(VaultProfileEntity())
        }

        val defaultTrophies = listOf(
            TrophyEntity("first_play", "Neon Initiate", "Play any arcade vault game once", "General", false, 0, 1, 15),
            TrophyEntity("century_score", "Century Surge", "Reach 100+ score in any game", "General", false, 0, 1, 20),
            TrophyEntity("score_1000", "Cyber Legend", "Surpass 1,000 points in any game", "Mastery", false, 0, 1, 50),
            TrophyEntity("brick_master", "Laser Shatter", "Destroy blocks for 500+ in Neon Brick Breaker DX", "Arcade", false, 0, 1, 35),
            TrophyEntity("snake_whisperer", "Vector Predator", "Eat neon orbs for 400+ in Cyber Snake 360", "Arcade", false, 0, 1, 35),
            TrophyEntity("gravity_defier", "Antigravity Ace", "Navigate 30+ neon pillars in Gravity Dash", "Runner", false, 0, 1, 35),
            TrophyEntity("score_2048", "Prism Architect", "Reach tile 2048 in 2048 Prism Glow", "Puzzle", false, 0, 1, 100)
        )
        vaultDao.insertInitialTrophies(defaultTrophies)
    }

    suspend fun resetVaultData() {
        vaultDao.clearGameStats()
        vaultDao.setProfile(VaultProfileEntity())
    }

    suspend fun updateProfile(profile: VaultProfileEntity) {
        vaultDao.setProfile(profile)
    }
}
