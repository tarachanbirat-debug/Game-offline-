package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface VaultDao {

    @Query("SELECT * FROM game_stats")
    fun getAllGameStats(): Flow<List<GameStatEntity>>

    @Query("SELECT * FROM game_stats WHERE gameId = :gameId LIMIT 1")
    fun getGameStat(gameId: String): Flow<GameStatEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateGameStat(stat: GameStatEntity)

    @Query("SELECT * FROM vault_profile WHERE id = 1 LIMIT 1")
    fun getProfile(): Flow<VaultProfileEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun setProfile(profile: VaultProfileEntity)

    @Query("SELECT * FROM trophies")
    fun getAllTrophies(): Flow<List<TrophyEntity>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertInitialTrophies(trophies: List<TrophyEntity>)

    @Update
    suspend fun updateTrophy(trophy: TrophyEntity)

    @Query("DELETE FROM game_stats")
    suspend fun clearGameStats()
}
