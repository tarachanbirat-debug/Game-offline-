package com.example.ui.screens

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Circle
import androidx.compose.material.icons.filled.Diamond
import androidx.compose.material.icons.filled.FiberManualRecord
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Token
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.GameStatEntity
import com.example.data.VaultProfileEntity
import com.example.engine.fx.Cyber3DHologramView
import com.example.engine.fx.Interactive3DHologramCard
import com.example.engine.fx.MeshShapeType
import com.example.ui.components.Cyber3DGameCard
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberBorderGlow
import com.example.ui.theme.CyberDark
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceElevated
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.HotMagenta
import com.example.ui.theme.LiquidGold
import com.example.ui.theme.MatrixGreen
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonIceBlue
import com.example.ui.theme.SolarOrange
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary

data class VaultGameMeta(
    val id: String,
    val title: String,
    val subtitle: String,
    val category: String,
    val tag: String,
    val primaryColor: Color,
    val secondaryColor: Color,
    val icon: ImageVector,
    val description: String
)

val ALL_GAMES = listOf(
    VaultGameMeta(
        id = "brick_breaker",
        title = "Neon Brick Breaker DX",
        subtitle = "Drag Paddle • Laser Cannon • Multiball",
        category = "Arcade Classics",
        tag = "FLAGSHIP",
        primaryColor = NeonCyan,
        secondaryColor = HotMagenta,
        icon = Icons.Default.Bolt,
        description = "Advanced drag-paddle physics with variable strike angles, multi-hit neon prisms, and explosive laser drops."
    ),
    VaultGameMeta(
        id = "cyber_snake",
        title = "Cyber Snake 360",
        subtitle = "Fluid Continuous Vector Motion",
        category = "Arcade Classics",
        tag = "POPULAR",
        primaryColor = MatrixGreen,
        secondaryColor = NeonCyan,
        icon = Icons.Default.FiberManualRecord,
        description = "Continuous 360-degree vector snake gliding with virtual stick steering, glowing particle trails, and score streaks."
    ),
    VaultGameMeta(
        id = "gravity_dash",
        title = "Gravity Dash",
        subtitle = "One-Tap Gravity Inverter Runner",
        category = "Hyper Runners",
        tag = "HARDCORE",
        primaryColor = HotMagenta,
        secondaryColor = ElectricPurple,
        icon = Icons.Default.KeyboardArrowRight,
        description = "One-tap antigravity runner dodging procedural cyber pillars with after-image ghosting trails and crystal boosts."
    ),
    VaultGameMeta(
        id = "prism_2048",
        title = "2048 Prism Glow",
        subtitle = "Glassmorphic Merging Puzzle",
        category = "Puzzle & Logic",
        tag = "LOGIC",
        primaryColor = LiquidGold,
        secondaryColor = SolarOrange,
        icon = Icons.Default.WorkspacePremium,
        description = "Tactile sliding merge puzzle with animated glassmorphic halos, undo mechanics, and harmonic chord synthesis."
    ),
    VaultGameMeta(
        id = "quantum_reflex",
        title = "Quantum Reflex",
        subtitle = "Chroma Resonance Timing",
        category = "Reflex Action",
        tag = "FAST-PACED",
        primaryColor = NeonCyan,
        secondaryColor = MatrixGreen,
        icon = Icons.Default.Circle,
        description = "High-speed reflex challenge syncing collapsing neon pulses in the core resonance zone for perfect streaks."
    ),
    VaultGameMeta(
        id = "aether_blaster",
        title = "Aether Blasters",
        subtitle = "Vector Space Blaster & Asteroids",
        category = "Reflex Action",
        tag = "RETRO",
        primaryColor = SolarOrange,
        secondaryColor = HotMagenta,
        icon = Icons.Default.Shield,
        description = "Inertial vector ship maneuvering through polygonal asteroid storms with twin laser pings and shard explosions."
    )
)

fun getGameBanner(id: String): Int {
    return when (id) {
        "brick_breaker" -> R.drawable.img_game_brick
        "cyber_snake" -> R.drawable.img_game_snake
        "gravity_dash" -> R.drawable.img_game_gravity
        "aether_blaster" -> R.drawable.img_game_blaster
        "prism_2048" -> R.drawable.img_game_brick
        "quantum_reflex" -> R.drawable.img_game_blaster
        else -> R.drawable.img_arcade_hero
    }
}

val CATEGORIES = listOf("All", "Arcade Classics", "Hyper Runners", "Puzzle & Logic", "Reflex Action")

@Composable
fun ArcadeHeroBanner(
    onQuickPlay: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = CyberSurfaceElevated),
        border = BorderStroke(1.5.dp, Brush.horizontalGradient(listOf(NeonCyan, HotMagenta)))
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp)
        ) {
            Image(
                painter = painterResource(id = R.drawable.img_arcade_hero),
                contentDescription = "Aether Vault Hero",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )

            // Scrim
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            listOf(
                                Color.Black.copy(alpha = 0.35f),
                                CyberDark.copy(alpha = 0.88f)
                            )
                        )
                    )
            )

            // Content
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.Center
                ) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = HotMagenta.copy(alpha = 0.25f),
                        border = BorderStroke(0.8.dp, HotMagenta)
                    ) {
                        Text(
                            text = "2D & 3D HARDWARE ACCELERATED",
                            color = HotMagenta,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "AETHER VAULT",
                        color = Color.White,
                        fontSize = 21.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "6 Custom Engines • Particle FX",
                        color = NeonCyan,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                    Surface(
                        onClick = onQuickPlay,
                        shape = RoundedCornerShape(12.dp),
                        color = NeonCyan,
                        border = BorderStroke(1.dp, Color.White)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = null,
                                tint = Color.Black,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = "QUICK PLAY",
                                color = Color.Black,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }

                // Embedded 3D Spinning Hologram Preview
                Box(
                    modifier = Modifier
                        .size(110.dp)
                        .clip(RoundedCornerShape(18.dp))
                        .background(CyberDark.copy(alpha = 0.6f))
                        .border(1.dp, NeonCyan.copy(alpha = 0.6f), RoundedCornerShape(18.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Cyber3DHologramView(
                        meshType = MeshShapeType.NEON_OCTAHEDRON,
                        glowColor = NeonCyan,
                        allowTouchRotate = false,
                        scale = 0.70f
                    )
                }
            }
        }
    }
}

@Composable
fun ArcadeHubScreen(
    profile: VaultProfileEntity,
    gameStats: List<GameStatEntity>,
    selectedCategory: String,
    onSelectCategory: (String) -> Unit,
    onLaunchGame: (id: String, title: String, category: String) -> Unit,
    modifier: Modifier = Modifier
) {
    val filteredGames = if (selectedCategory == "All") {
        ALL_GAMES
    } else {
        ALL_GAMES.filter { it.category == selectedCategory }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(CyberDark.copy(alpha = 0.85f))
            .statusBarsPadding(),
        contentPadding = PaddingValues(bottom = 110.dp)
    ) {
        // Vault Header
        item {
            VaultHeader(profile = profile)
        }

        // Hero 3D Graphic Banner
        item {
            ArcadeHeroBanner(
                onQuickPlay = {
                    val quickGame = ALL_GAMES.random()
                    onLaunchGame(quickGame.id, quickGame.title, quickGame.category)
                }
            )
        }

        // Real-Time 3D Hologram Laboratory
        item {
            Interactive3DHologramCard()
        }

        // Category Filter Row
        item {
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 10.dp),
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(CATEGORIES) { category ->
                    val isSelected = category == selectedCategory
                    Surface(
                        onClick = { onSelectCategory(category) },
                        shape = RoundedCornerShape(16.dp),
                        color = if (isSelected) NeonCyan.copy(alpha = 0.18f) else CyberSurfaceElevated,
                        border = BorderStroke(
                            1.dp,
                            if (isSelected) NeonCyan.copy(alpha = 0.8f) else CyberBorder.copy(alpha = 0.6f)
                        )
                    ) {
                        Text(
                            text = category,
                            color = if (isSelected) NeonCyan else TextSecondary,
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                        )
                    }
                }
            }
        }

        // Vault Games List with 3D Tilt Cards
        items(filteredGames, key = { it.id }) { game ->
            val stat = gameStats.find { it.gameId == game.id }
            val bestScore = stat?.highScore ?: 0L
            val playCount = stat?.playCount ?: 0

            Cyber3DGameCard(
                game = game,
                bannerDrawableId = getGameBanner(game.id),
                bestScore = bestScore,
                playCount = playCount,
                onLaunch = { onLaunchGame(game.id, game.title, game.category) }
            )
        }
    }
}

@Composable
fun VaultHeader(profile: VaultProfileEntity) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        shape = RoundedCornerShape(22.dp),
        color = CyberSurfaceElevated,
        border = BorderStroke(1.2.dp, CyberBorder.copy(alpha = 0.8f))
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Pilot Info
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.linearGradient(listOf(NeonCyan, HotMagenta))
                            )
                            .border(1.5.dp, Color.White.copy(alpha = 0.6f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                text = profile.playerName,
                                color = TextPrimary,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = NeonCyan.copy(alpha = 0.2f),
                                border = BorderStroke(0.8.dp, NeonCyan.copy(alpha = 0.6f))
                            ) {
                                Text(
                                    text = "LVL ${profile.playerLevel}",
                                    color = NeonCyan,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Text(
                            text = "OFFLINE VAULT • 100% CLIENT-SIDE",
                            color = MatrixGreen,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                // Currency Chips
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = CyberSurface,
                        border = BorderStroke(1.dp, LiquidGold.copy(alpha = 0.5f))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(text = "🪙", fontSize = 12.sp)
                            Text(
                                text = "${profile.totalCoins}",
                                color = LiquidGold,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = CyberSurface,
                        border = BorderStroke(1.dp, NeonCyan.copy(alpha = 0.5f))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(text = "💎", fontSize = 12.sp)
                            Text(
                                text = "${profile.totalGems}",
                                color = NeonCyan,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // XP Progress
            val xpIntoLevel = profile.xp % 300
            val progress = (xpIntoLevel / 300f).coerceIn(0.05f, 1f)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = "XP PROGRESS", color = TextTertiary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                Text(text = "$xpIntoLevel / 300 XP", color = TextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
            }
            Spacer(modifier = Modifier.height(6.dp))
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp)),
                color = NeonCyan,
                trackColor = CyberSurface
            )
        }
    }
}

@Composable
fun GameVaultCard(
    game: VaultGameMeta,
    bestScore: Long,
    playCount: Int,
    onLaunch: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "card_glow")
    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 0.85f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glow"
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .testTag("game_card_${game.id}")
            .clickable { onLaunch() },
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = CyberSurfaceElevated),
        border = BorderStroke(1.2.dp, game.primaryColor.copy(alpha = glowAlpha))
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Category & Tag
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = game.primaryColor.copy(alpha = 0.18f),
                        border = BorderStroke(0.8.dp, game.primaryColor.copy(alpha = 0.6f))
                    ) {
                        Text(
                            text = game.tag,
                            color = game.primaryColor,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                        )
                    }
                    Text(
                        text = game.category,
                        color = TextTertiary,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }

                // Best Score Pill
                if (bestScore > 0) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = CyberSurface,
                        border = BorderStroke(0.8.dp, LiquidGold.copy(alpha = 0.6f))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(text = "BEST", color = TextTertiary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                            Text(
                                text = "$bestScore",
                                color = LiquidGold,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Title & Subtitle
            Text(
                text = game.title,
                color = TextPrimary,
                fontSize = 19.sp,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.Monospace
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = game.subtitle,
                color = game.primaryColor,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold
            )

            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = game.description,
                color = TextSecondary,
                fontSize = 12.sp,
                lineHeight = 16.sp
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Launch Action Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "RUNS: $playCount",
                    color = TextTertiary,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )

                Surface(
                    onClick = onLaunch,
                    shape = RoundedCornerShape(14.dp),
                    color = game.primaryColor.copy(alpha = 0.2f),
                    border = BorderStroke(1.2.dp, game.primaryColor.copy(alpha = 0.8f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = "Play",
                            tint = game.primaryColor,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "LAUNCH",
                            color = game.primaryColor,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }
    }
}
