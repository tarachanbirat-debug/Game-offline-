package com.example.ui.screens

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.VolumeMute
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Waves
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.audio.SoundEngine
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberDark
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceElevated
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.HotMagenta
import com.example.ui.theme.LiquidGold
import com.example.ui.theme.MatrixGreen
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.SolarOrange
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary

data class SynthEffect(
    val title: String,
    val description: String,
    val color: Color,
    val onTrigger: () -> Unit
)

@Composable
fun SoundDeckScreen(
    soundEngine: SoundEngine,
    modifier: Modifier = Modifier
) {
    val isSoundOn by soundEngine.isSoundEnabled.collectAsState()
    val isAmbientOn by soundEngine.isAmbientMusicEnabled.collectAsState()
    val visualizerLevels by soundEngine.audioVisualizerLevels.collectAsState()

    val effects = listOf(
        SynthEffect("Laser Ping", "980Hz -> 240Hz Pitch Sweep", NeonCyan) { soundEngine.playLaserPing() },
        SynthEffect("Bass Thump", "120Hz Punch + Sub Decay", SolarOrange) { soundEngine.playBassThump() },
        SynthEffect("Crystal Chime", "E5-G#5-B5 Harmonic Arpeggio", MatrixGreen) { soundEngine.playScoreChime() },
        SynthEffect("Brick Crunch", "White Noise + Tone Burst", HotMagenta) { soundEngine.playBrickBreak() },
        SynthEffect("Gravity Flip", "160Hz -> 720Hz Phase Warp", ElectricPurple) { soundEngine.playGravityFlip() },
        SynthEffect("Merge Fanfare", "Harmonic Perfect Fifth", LiquidGold) { soundEngine.playMergeChime(3) },
        SynthEffect("Power-Up 8-Bit", "C5-E5-G5-C6 Ascension", NeonCyan) { soundEngine.playPowerUp() },
        SynthEffect("Game Over", "Minor Dissonant Descent", HotMagenta) { soundEngine.playGameOverChord() }
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CyberDark)
            .statusBarsPadding()
            .padding(bottom = 110.dp)
            .padding(horizontal = 16.dp)
    ) {
        // Header
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            shape = RoundedCornerShape(22.dp),
            color = CyberSurfaceElevated,
            border = BorderStroke(1.2.dp, HotMagenta.copy(alpha = 0.7f))
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(imageVector = Icons.Default.GraphicEq, contentDescription = null, tint = HotMagenta, modifier = Modifier.size(24.dp))
                        Column {
                            Text(text = "SYNTHESIZER LAB", color = HotMagenta, fontSize = 16.sp, fontWeight = FontWeight.Black, fontFamily = FontFamily.Monospace)
                            Text(text = "Zero MP3s • 100% Procedural PCM", color = MatrixGreen, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        }
                    }

                    Switch(
                        checked = isSoundOn,
                        onCheckedChange = { soundEngine.setSoundEnabled(it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = NeonCyan,
                            checkedTrackColor = NeonCyan.copy(alpha = 0.3f),
                            uncheckedThumbColor = TextTertiary,
                            uncheckedTrackColor = CyberSurface
                        )
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Real-time 12-band Animated Visualizer
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(70.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(CyberDark.copy(alpha = 0.6f))
                        .border(1.dp, CyberBorder, RoundedCornerShape(12.dp))
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val numBands = visualizerLevels.size
                        val spacing = 8.dp.toPx()
                        val totalSpacing = spacing * (numBands - 1)
                        val barWidth = (size.width - totalSpacing) / numBands

                        for (i in 0 until numBands) {
                            val level = visualizerLevels[i]
                            val barHeight = (size.height * level).coerceAtLeast(4f)
                            val x = i * (barWidth + spacing)
                            val y = size.height - barHeight

                            val barColor = if (i % 2 == 0) NeonCyan else HotMagenta
                            drawRoundRect(
                                color = barColor.copy(alpha = 0.85f),
                                topLeft = Offset(x, y),
                                size = Size(barWidth, barHeight),
                                cornerRadius = androidx.compose.ui.geometry.CornerRadius(4f, 4f)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Ambient Drone Toggle Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(imageVector = Icons.Default.Waves, contentDescription = null, tint = LiquidGold, modifier = Modifier.size(18.dp))
                        Text(text = "Ambient Sci-Fi Drone", color = TextPrimary, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                    }
                    Switch(
                        checked = isAmbientOn,
                        onCheckedChange = { soundEngine.setAmbientMusicEnabled(it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = LiquidGold,
                            checkedTrackColor = LiquidGold.copy(alpha = 0.3f),
                            uncheckedThumbColor = TextTertiary,
                            uncheckedTrackColor = CyberSurface
                        )
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "TOUCH SFX SYNTH PADS",
            color = TextTertiary,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.padding(start = 4.dp, bottom = 8.dp)
        )

        // SFX Trigger Pads Grid
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(bottom = 16.dp)
        ) {
            items(effects.size) { index ->
                val eff = effects[index]
                Surface(
                    onClick = eff.onTrigger,
                    shape = RoundedCornerShape(16.dp),
                    color = CyberSurfaceElevated,
                    border = BorderStroke(1.dp, eff.color.copy(alpha = 0.65f)),
                    modifier = Modifier.height(86.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(12.dp),
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = eff.title,
                            color = eff.color,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = eff.description,
                            color = TextTertiary,
                            fontSize = 10.sp,
                            lineHeight = 13.sp
                        )
                    }
                }
            }
        }
    }
}
