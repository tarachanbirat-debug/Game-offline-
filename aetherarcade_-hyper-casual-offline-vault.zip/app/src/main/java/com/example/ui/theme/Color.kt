package com.example.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// Base Dark Backgrounds
val CyberDark = Color(0xFF0A0E17)
val CyberDarkElevated = Color(0xFF101726)
val CyberSurface = Color(0xFF141F33)
val CyberSurfaceElevated = Color(0xFF1B2844)
val CyberBorder = Color(0xFF263A60)
val CyberBorderGlow = Color(0xFF00F0FF)

// Vibrant Neon Accents
val NeonCyan = Color(0xFF00F0FF)
val HotMagenta = Color(0xFFFF007F)
val LiquidGold = Color(0xFFFFD700)
val ElectricPurple = Color(0xFF8A2BE2)
val MatrixGreen = Color(0xFF00FF66)
val SolarOrange = Color(0xFFFF6A00)
val LaserRed = Color(0xFFFF1744)
val NeonIceBlue = Color(0xFF7000FF)

// Text Colors
val TextPrimary = Color(0xFFF0F6FC)
val TextSecondary = Color(0xFF8B9BB4)
val TextTertiary = Color(0xFF5A6B84)

// Card Glass Brushes
val CyberGradientCyan = Brush.linearGradient(
    listOf(NeonCyan.copy(alpha = 0.85f), ElectricPurple.copy(alpha = 0.85f))
)
val CyberGradientMagenta = Brush.linearGradient(
    listOf(HotMagenta.copy(alpha = 0.85f), SolarOrange.copy(alpha = 0.85f))
)
val CyberGradientGold = Brush.linearGradient(
    listOf(LiquidGold.copy(alpha = 0.9f), SolarOrange.copy(alpha = 0.85f))
)
val CyberGradientGreen = Brush.linearGradient(
    listOf(MatrixGreen.copy(alpha = 0.85f), NeonCyan.copy(alpha = 0.85f))
)
val CyberGlassBrush = Brush.verticalGradient(
    listOf(CyberSurfaceElevated.copy(alpha = 0.85f), CyberSurface.copy(alpha = 0.70f))
)
