package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.VolumeMute
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberDark
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceElevated
import com.example.ui.theme.HotMagenta
import com.example.ui.theme.LiquidGold
import com.example.ui.theme.MatrixGreen
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.SolarOrange
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary
import com.example.viewmodel.VaultTab

/**
 * CRT Scanline & Subtle Bloom Vignette overlay drawn on top of canvas
 */
@Composable
fun CrtScanlinesOverlay(modifier: Modifier = Modifier, enabled: Boolean = true) {
    if (!enabled) return

    Canvas(modifier = modifier.fillMaxSize()) {
        val step = 4.dp.toPx()
        val numLines = (size.height / step).toInt()
        val scanlineColor = Color(0x12000000)

        for (i in 0 until numLines) {
            val y = i * step
            drawLine(
                color = scanlineColor,
                start = Offset(0f, y),
                end = Offset(size.width, y),
                strokeWidth = 1.2f
            )
        }

        // Ambient border vignette glow
        drawRect(
            brush = Brush.radialGradient(
                colors = listOf(Color.Transparent, Color(0x3500F0FF)),
                center = Offset(size.width / 2f, size.height / 2f),
                radius = size.width.coerceAtLeast(size.height) * 0.7f
            )
        )
    }
}

/**
 * Floating glassmorphism dock navigation bar at screen bottom
 */
@Composable
fun FloatingGlassDock(
    currentTab: VaultTab,
    onSelectTab: (VaultTab) -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .windowInsetsPadding(WindowInsets.navigationBars)
            .padding(horizontal = 24.dp, vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            shape = RoundedCornerShape(28.dp),
            color = CyberSurfaceElevated.copy(alpha = 0.88f),
            border = BorderStroke(1.2.dp, CyberBorder.copy(alpha = 0.8f)),
            shadowElevation = 16.dp,
            modifier = Modifier.testTag("floating_glass_dock")
        ) {
            Row(
                modifier = Modifier
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                DockItem(
                    label = "Arcade",
                    icon = Icons.Default.SportsEsports,
                    isSelected = currentTab == VaultTab.HUB,
                    accentColor = NeonCyan,
                    onClick = { onSelectTab(VaultTab.HUB) }
                )
                DockItem(
                    label = "Trophies",
                    icon = Icons.Default.EmojiEvents,
                    isSelected = currentTab == VaultTab.TROPHIES,
                    accentColor = LiquidGold,
                    onClick = { onSelectTab(VaultTab.TROPHIES) }
                )
                DockItem(
                    label = "Sound Deck",
                    icon = Icons.Default.GraphicEq,
                    isSelected = currentTab == VaultTab.SOUND_DECK,
                    accentColor = HotMagenta,
                    onClick = { onSelectTab(VaultTab.SOUND_DECK) }
                )
                DockItem(
                    label = "Settings",
                    icon = Icons.Default.Settings,
                    isSelected = currentTab == VaultTab.SETTINGS,
                    accentColor = MatrixGreen,
                    onClick = { onSelectTab(VaultTab.SETTINGS) }
                )
            }
        }
    }
}

@Composable
private fun DockItem(
    label: String,
    icon: ImageVector,
    isSelected: Boolean,
    accentColor: Color,
    onClick: () -> Unit
) {
    val scale = animateFloatAsState(
        targetValue = if (isSelected) 1.05f else 0.95f,
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label = "dock_scale"
    )

    val backgroundBrush = if (isSelected) {
        Brush.horizontalGradient(
            listOf(accentColor.copy(alpha = 0.22f), accentColor.copy(alpha = 0.08f))
        )
    } else {
        Brush.linearGradient(listOf(Color.Transparent, Color.Transparent))
    }

    Box(
        modifier = Modifier
            .scale(scale.value)
            .clip(RoundedCornerShape(20.dp))
            .background(backgroundBrush)
            .border(
                width = if (isSelected) 1.dp else 0.dp,
                color = if (isSelected) accentColor.copy(alpha = 0.6f) else Color.Transparent,
                shape = RoundedCornerShape(20.dp)
            )
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick
            )
            .padding(horizontal = 14.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = if (isSelected) accentColor else TextSecondary,
                modifier = Modifier.size(20.dp)
            )
            if (isSelected) {
                Text(
                    text = label,
                    color = TextPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}

/**
 * Universal In-Game Top HUD (FPS, Score, Streak, Pause)
 */
@Composable
fun GameHudHeader(
    gameTitle: String,
    score: Long,
    fps: Int,
    streak: Int,
    accentColor: Color,
    onPauseClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // FPS & Game Title pill
        Surface(
            shape = RoundedCornerShape(14.dp),
            color = CyberSurface.copy(alpha = 0.85f),
            border = BorderStroke(1.dp, CyberBorder)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "${fps}FPS",
                    color = if (fps >= 55) MatrixGreen else SolarOrange,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "•",
                    color = TextTertiary,
                    fontSize = 11.sp
                )
                Text(
                    text = gameTitle,
                    color = TextPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        // Score & Streak Counter
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = CyberSurfaceElevated.copy(alpha = 0.9f),
            border = BorderStroke(1.2.dp, accentColor.copy(alpha = 0.7f))
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 5.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (streak > 1) {
                    Text(
                        text = "x$streak",
                        color = HotMagenta,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.ExtraBold,
                        fontFamily = FontFamily.Monospace
                    )
                }
                Text(
                    text = "$score",
                    color = accentColor,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        // Pause Action Button
        IconButton(
            onClick = onPauseClick,
            modifier = Modifier
                .size(38.dp)
                .clip(CircleShape)
                .background(CyberSurface.copy(alpha = 0.85f))
                .border(1.dp, CyberBorder, CircleShape)
                .testTag("game_pause_button")
        ) {
            Icon(
                imageVector = Icons.Default.Pause,
                contentDescription = "Pause Game",
                tint = NeonCyan,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}

/**
 * Universal In-Game Pause Dialog
 */
@Composable
fun GamePauseDialog(
    isOpen: Boolean,
    gameTitle: String,
    score: Long,
    onResume: () -> Unit,
    onRestart: () -> Unit,
    onExit: () -> Unit,
    isSoundOn: Boolean,
    onToggleSound: () -> Unit
) {
    AnimatedVisibility(
        visible = isOpen,
        enter = fadeIn(),
        exit = fadeOut()
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(CyberDark.copy(alpha = 0.82f))
                .clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { },
            contentAlignment = Alignment.Center
        ) {
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = CyberSurfaceElevated),
                border = BorderStroke(1.5.dp, NeonCyan.copy(alpha = 0.7f)),
                modifier = Modifier
                    .width(310.dp)
                    .padding(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "SYSTEM PAUSED",
                        color = NeonCyan,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = gameTitle,
                        color = TextSecondary,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "CURRENT SCORE",
                        color = TextTertiary,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "$score",
                        color = LiquidGold,
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace
                    )

                    Spacer(modifier = Modifier.height(24.dp))

                    // Buttons
                    CyberButton(
                        text = "RESUME",
                        icon = Icons.Default.PlayArrow,
                        color = NeonCyan,
                        onClick = onResume,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    CyberButton(
                        text = "RESTART RUN",
                        icon = Icons.Default.Refresh,
                        color = HotMagenta,
                        onClick = onRestart,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CyberIconButton(
                            icon = if (isSoundOn) Icons.Default.VolumeUp else Icons.Default.VolumeMute,
                            onClick = onToggleSound,
                            tint = if (isSoundOn) MatrixGreen else TextTertiary
                        )
                        CyberButton(
                            text = "EXIT TO VAULT",
                            icon = Icons.Default.Close,
                            color = TextSecondary,
                            onClick = onExit,
                            modifier = Modifier.weight(1f).padding(start = 12.dp)
                        )
                    }
                }
            }
        }
    }
}

/**
 * Universal Game Over Screen with high score celebration
 */
@Composable
fun GameOverDialog(
    isOpen: Boolean,
    gameTitle: String,
    score: Long,
    highScore: Long,
    isNewHighScore: Boolean,
    coinsEarned: Long,
    onRestart: () -> Unit,
    onExit: () -> Unit
) {
    AnimatedVisibility(
        visible = isOpen,
        enter = fadeIn(),
        exit = fadeOut()
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(CyberDark.copy(alpha = 0.88f)),
            contentAlignment = Alignment.Center
        ) {
            Card(
                shape = RoundedCornerShape(26.dp),
                colors = CardDefaults.cardColors(containerColor = CyberSurfaceElevated),
                border = BorderStroke(1.5.dp, if (isNewHighScore) LiquidGold else HotMagenta),
                modifier = Modifier
                    .width(320.dp)
                    .padding(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    if (isNewHighScore) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.WorkspacePremium,
                                contentDescription = null,
                                tint = LiquidGold,
                                modifier = Modifier.size(24.dp)
                            )
                            Text(
                                text = "NEW RECORD!",
                                color = LiquidGold,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Black,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    } else {
                        Text(
                            text = "RUN TERMINATED",
                            color = HotMagenta,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = gameTitle, color = TextSecondary, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "FINAL SCORE",
                        color = TextTertiary,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "$score",
                        color = if (isNewHighScore) LiquidGold else NeonCyan,
                        fontSize = 34.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace
                    )

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "BEST RECORD: $highScore",
                        color = TextSecondary,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = CyberSurface,
                        border = BorderStroke(1.dp, CyberBorder)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(text = "🪙 +$coinsEarned Coins Vaulted", color = LiquidGold, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    CyberButton(
                        text = "INSTANT REPLAY",
                        icon = Icons.Default.Refresh,
                        color = NeonCyan,
                        onClick = onRestart,
                        modifier = Modifier.fillMaxWidth().testTag("replay_button")
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    CyberButton(
                        text = "BACK TO VAULT",
                        icon = Icons.Default.SportsEsports,
                        color = TextSecondary,
                        onClick = onExit,
                        modifier = Modifier.fillMaxWidth().testTag("exit_to_vault_button")
                    )
                }
            }
        }
    }
}

@Composable
fun CyberButton(
    text: String,
    icon: ImageVector? = null,
    color: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(14.dp),
        color = color.copy(alpha = 0.16f),
        border = BorderStroke(1.2.dp, color.copy(alpha = 0.75f)),
        modifier = modifier.height(46.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxSize(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (icon != null) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = color,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
            }
            Text(
                text = text,
                color = color,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}

@Composable
fun CyberIconButton(
    icon: ImageVector,
    onClick: () -> Unit,
    tint: Color,
    modifier: Modifier = Modifier
) {
    IconButton(
        onClick = onClick,
        modifier = modifier
            .size(46.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(CyberSurface)
            .border(1.dp, CyberBorder, RoundedCornerShape(14.dp))
    ) {
        Icon(imageVector = icon, contentDescription = null, tint = tint, modifier = Modifier.size(20.dp))
    }
}
