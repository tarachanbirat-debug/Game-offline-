package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val ArcadeDarkColorScheme = darkColorScheme(
    primary = NeonCyan,
    onPrimary = CyberDark,
    primaryContainer = CyberSurfaceElevated,
    onPrimaryContainer = NeonCyan,
    secondary = HotMagenta,
    onSecondary = CyberDark,
    secondaryContainer = CyberSurfaceElevated,
    onSecondaryContainer = HotMagenta,
    tertiary = LiquidGold,
    onTertiary = CyberDark,
    background = CyberDark,
    onBackground = TextPrimary,
    surface = CyberSurface,
    onSurface = TextPrimary,
    surfaceVariant = CyberSurfaceElevated,
    onSurfaceVariant = TextSecondary,
    outline = CyberBorder,
    outlineVariant = CyberBorder.copy(alpha = 0.5f)
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = ArcadeDarkColorScheme,
        typography = Typography,
        content = content
    )
}

@Composable
fun AetherArcadeTheme(
    content: @Composable () -> Unit
) = MyApplicationTheme(content = content)
