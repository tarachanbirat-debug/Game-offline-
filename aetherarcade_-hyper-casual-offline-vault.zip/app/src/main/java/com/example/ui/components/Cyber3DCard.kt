package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.screens.VaultGameMeta
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberDark
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceElevated
import com.example.ui.theme.HotMagenta
import com.example.ui.theme.LiquidGold
import com.example.ui.theme.MatrixGreen
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary
import kotlinx.coroutines.launch

/**
 * 3D Interactive Tilt Card with Dynamic Specular Glare and Parallax Depth
 */
@Composable
fun Cyber3DGameCard(
    game: VaultGameMeta,
    bannerDrawableId: Int?,
    bestScore: Long,
    playCount: Int,
    onLaunch: () -> Unit,
    modifier: Modifier = Modifier
) {
    val coroutineScope = rememberCoroutineScope()
    val density = LocalDensity.current.density

    val rotX = remember { Animatable(0f) }
    val rotY = remember { Animatable(0f) }
    val cardElevation = remember { Animatable(0f) }

    val springSpec = spring<Float>(
        dampingRatio = Spring.DampingRatioMediumBouncy,
        stiffness = Spring.StiffnessLow
    )

    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 9.dp)
            .testTag("game_card_${game.id}")
            .graphicsLayer {
                rotationX = rotX.value
                rotationY = rotY.value
                cameraDistance = 18f * density
                shadowElevation = 8f + cardElevation.value
                scaleX = 1f + cardElevation.value * 0.002f
                scaleY = 1f + cardElevation.value * 0.002f
            }
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = {
                        coroutineScope.launch { cardElevation.animateTo(24f, springSpec) }
                    },
                    onDragEnd = {
                        coroutineScope.launch {
                            rotX.animateTo(0f, springSpec)
                        }
                        coroutineScope.launch {
                            rotY.animateTo(0f, springSpec)
                        }
                        coroutineScope.launch {
                            cardElevation.animateTo(0f, springSpec)
                        }
                    },
                    onDragCancel = {
                        coroutineScope.launch { rotX.animateTo(0f, springSpec) }
                        coroutineScope.launch { rotY.animateTo(0f, springSpec) }
                        coroutineScope.launch { cardElevation.animateTo(0f, springSpec) }
                    },
                    onDrag = { change, dragAmount ->
                        change.consume()
                        val newRotY = (rotY.value + dragAmount.x * 0.15f).coerceIn(-18f, 18f)
                        val newRotX = (rotX.value - dragAmount.y * 0.15f).coerceIn(-18f, 18f)
                        coroutineScope.launch {
                            rotY.snapTo(newRotY)
                            rotX.snapTo(newRotX)
                        }
                    }
                )
            }
            .clickable { onLaunch() },
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = CyberSurfaceElevated),
        border = BorderStroke(1.5.dp, game.primaryColor.copy(alpha = 0.85f))
    ) {
        Box(modifier = Modifier.fillMaxWidth()) {
            Column {
                // Banner Graphic Area (2D / 3D Rendered Art)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(135.dp)
                        .clip(RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp))
                        .background(CyberDark)
                ) {
                    if (bannerDrawableId != null) {
                        Image(
                            painter = painterResource(id = bannerDrawableId),
                            contentDescription = game.title,
                            modifier = Modifier
                                .fillMaxSize()
                                .graphicsLayer {
                                    // Subtle parallax translation opposite to card tilt
                                    translationX = -rotY.value * 1.5f
                                    translationY = -rotX.value * 1.5f
                                    scaleX = 1.08f
                                    scaleY = 1.08f
                                },
                            contentScale = ContentScale.Crop
                        )
                    }

                    // Cyber gradient overlay for text readability
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    listOf(
                                        Color.Black.copy(alpha = 0.2f),
                                        Color.Transparent,
                                        CyberSurfaceElevated.copy(alpha = 0.95f)
                                    )
                                )
                            )
                    )

                    // Top Badges
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Tag Pill
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = game.primaryColor.copy(alpha = 0.85f),
                            border = BorderStroke(0.8.dp, Color.White.copy(alpha = 0.6f))
                        ) {
                            Text(
                                text = game.tag,
                                color = Color.Black,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Black,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
                            )
                        }

                        // 3D Tilt Badge
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = CyberDark.copy(alpha = 0.75f),
                            border = BorderStroke(0.8.dp, NeonCyan.copy(alpha = 0.6f))
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(3.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Sync,
                                    contentDescription = null,
                                    tint = NeonCyan,
                                    modifier = Modifier.size(12.dp)
                                )
                                Text(
                                    text = "3D TILT",
                                    color = NeonCyan,
                                    fontSize = 9.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                // Card Details & Metrics Area
                Column(
                    modifier = Modifier.padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = game.title,
                                color = TextPrimary,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Black,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = game.subtitle,
                                color = game.primaryColor,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        if (bestScore > 0) {
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = CyberSurface,
                                border = BorderStroke(1.dp, LiquidGold.copy(alpha = 0.7f))
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.WorkspacePremium,
                                        contentDescription = null,
                                        tint = LiquidGold,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Column {
                                        Text(
                                            text = "BEST",
                                            color = TextTertiary,
                                            fontSize = 8.sp,
                                            fontFamily = FontFamily.Monospace
                                        )
                                        Text(
                                            text = "$bestScore",
                                            color = LiquidGold,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = game.description,
                        color = TextSecondary,
                        fontSize = 11.sp,
                        lineHeight = 15.sp
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Launch Footer
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = "RUNS: $playCount",
                                color = TextTertiary,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "• 60 FPS",
                                color = MatrixGreen,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Surface(
                            onClick = onLaunch,
                            shape = RoundedCornerShape(12.dp),
                            color = game.primaryColor.copy(alpha = 0.25f),
                            border = BorderStroke(1.2.dp, game.primaryColor)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(5.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PlayArrow,
                                    contentDescription = "Play",
                                    tint = game.primaryColor,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = "LAUNCH",
                                    color = game.primaryColor,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Black,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }
            }

            // Holographic Specular Glare Reflection moving dynamically with tilt
            val glareOffsetX = (rotY.value / 18f) * 300f
            val glareOffsetY = (rotX.value / 18f) * 300f
            Box(
                modifier = Modifier
                    .matchParentSize()
                    .clip(RoundedCornerShape(22.dp))
                    .background(
                        Brush.linearGradient(
                            colors = listOf(
                                Color.Transparent,
                                Color.White.copy(alpha = (kotlin.math.abs(rotX.value) + kotlin.math.abs(rotY.value)) * 0.008f),
                                Color.Transparent
                            ),
                            start = Offset(glareOffsetX, glareOffsetY),
                            end = Offset(glareOffsetX + 400f, glareOffsetY + 400f)
                        )
                    )
            )
        }
    }
}
