package com.example.engine.fx

import androidx.compose.ui.geometry.Offset
import kotlin.random.Random

class ScreenShakeController {
    var trauma: Float = 0f
        private set

    var offsetX: Float = 0f
        private set

    var offsetY: Float = 0f
        private set

    fun addTrauma(amount: Float) {
        trauma = (trauma + amount).coerceAtMost(1f)
    }

    fun update(dt: Float) {
        if (trauma > 0f) {
            val shake = trauma * trauma // Non-linear shake feel
            val maxOffset = shake * 22f
            offsetX = (Random.nextFloat() * 2f - 1f) * maxOffset
            offsetY = (Random.nextFloat() * 2f - 1f) * maxOffset
            trauma = (trauma - dt * 2.8f).coerceAtLeast(0f)
        } else {
            offsetX = 0f
            offsetY = 0f
        }
    }

    fun getOffset(): Offset = Offset(offsetX, offsetY)

    fun reset() {
        trauma = 0f
        offsetX = 0f
        offsetY = 0f
    }
}
