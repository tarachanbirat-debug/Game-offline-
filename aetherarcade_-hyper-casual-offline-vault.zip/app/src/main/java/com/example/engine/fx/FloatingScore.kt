package com.example.engine.fx

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.nativeCanvas

data class FloatingText(
    var text: String,
    var x: Float,
    var y: Float,
    var vy: Float = -2.5f,
    val color: Color,
    val fontSize: Float = 42f,
    val maxLife: Float = 0.85f,
    var life: Float = maxLife
)

class FloatingTextController {
    private val texts = mutableListOf<FloatingText>()

    fun spawn(text: String, x: Float, y: Float, color: Color, fontSize: Float = 42f) {
        texts.add(FloatingText(text = text, x = x, y = y, color = color, fontSize = fontSize))
    }

    fun update(dt: Float) {
        val iterator = texts.iterator()
        while (iterator.hasNext()) {
            val t = iterator.next()
            t.life -= dt
            if (t.life <= 0f) {
                iterator.remove()
                continue
            }
            t.y += t.vy
            t.vy *= 0.95f
        }
    }

    fun render(drawScope: DrawScope) {
        val paint = android.graphics.Paint().apply {
            isAntiAlias = true
            isFakeBoldText = true
            textAlign = android.graphics.Paint.Align.CENTER
        }

        for (i in texts.indices) {
            val t = texts[i]
            val alphaRatio = (t.life / t.maxLife).coerceIn(0f, 1f)
            paint.textSize = t.fontSize * (1f + (1f - alphaRatio) * 0.25f)

            // Outer shadow / glow
            paint.setShadowLayer(14f, 0f, 0f, android.graphics.Color.argb((alphaRatio * 220).toInt(), 0, 240, 255))
            paint.color = android.graphics.Color.argb(
                (alphaRatio * 255).toInt(),
                (t.color.red * 255).toInt(),
                (t.color.green * 255).toInt(),
                (t.color.blue * 255).toInt()
            )

            drawScope.drawContext.canvas.nativeCanvas.drawText(
                t.text,
                t.x,
                t.y,
                paint
            )
        }
    }

    fun clear() {
        texts.clear()
    }
}
