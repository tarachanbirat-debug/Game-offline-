package com.example.engine.fx

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChangeCircle
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberDark
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.HotMagenta
import com.example.ui.theme.LiquidGold
import com.example.ui.theme.MatrixGreen
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

data class Vec3(val x: Float, val y: Float, val z: Float) {
    operator fun plus(other: Vec3) = Vec3(x + other.x, y + other.y, z + other.z)
    operator fun minus(other: Vec3) = Vec3(x - other.x, y - other.y, z - other.z)
    operator fun times(scalar: Float) = Vec3(x * scalar, y * scalar, z * scalar)

    fun cross(o: Vec3): Vec3 = Vec3(
        y * o.z - z * o.y,
        z * o.x - x * o.z,
        x * o.y - y * o.x
    )

    fun dot(o: Vec3): Float = x * o.x + y * o.y + z * o.z

    fun length(): Float = sqrt(x * x + y * y + z * z)

    fun normalized(): Vec3 {
        val len = length()
        return if (len > 0.0001f) Vec3(x / len, y / len, z / len) else Vec3(0f, 0f, 1f)
    }

    fun rotateX(angle: Float): Vec3 {
        val c = cos(angle)
        val s = sin(angle)
        return Vec3(x, y * c - z * s, y * s + z * c)
    }

    fun rotateY(angle: Float): Vec3 {
        val c = cos(angle)
        val s = sin(angle)
        return Vec3(x * c + z * s, y, -x * s + z * c)
    }

    fun rotateZ(angle: Float): Vec3 {
        val c = cos(angle)
        val s = sin(angle)
        return Vec3(x * c - y * s, x * s + y * c, z)
    }
}

data class MeshFace(
    val vIndices: List<Int>,
    val baseColor: Color
)

data class Mesh3D(
    val vertices: List<Vec3>,
    val edges: List<Pair<Int, Int>>,
    val faces: List<MeshFace>
)

enum class MeshShapeType(val label: String) {
    CYBER_CUBE("Cyber Tesseract"),
    NEON_OCTAHEDRON("Crystal Prism"),
    QUANTUM_PYRAMID("Nova Pyramid"),
    AETHER_TORUS("Quantum Rings")
}

object MeshFactory {
    fun createCube(size: Float = 100f): Mesh3D {
        val s = size / 2f
        val v = listOf(
            Vec3(-s, -s, -s), // 0
            Vec3(s, -s, -s),  // 1
            Vec3(s, s, -s),   // 2
            Vec3(-s, s, -s),  // 3
            Vec3(-s, -s, s),  // 4
            Vec3(s, -s, s),   // 5
            Vec3(s, s, s),    // 6
            Vec3(-s, s, s)    // 7
        )
        val edges = listOf(
            0 to 1, 1 to 2, 2 to 3, 3 to 0,
            4 to 5, 5 to 6, 6 to 7, 7 to 4,
            0 to 4, 1 to 5, 2 to 6, 3 to 7
        )
        val faces = listOf(
            MeshFace(listOf(0, 1, 2, 3), NeonCyan),
            MeshFace(listOf(5, 4, 7, 6), HotMagenta),
            MeshFace(listOf(4, 0, 3, 7), MatrixGreen),
            MeshFace(listOf(1, 5, 6, 2), LiquidGold),
            MeshFace(listOf(4, 5, 1, 0), NeonCyan),
            MeshFace(listOf(3, 2, 6, 7), HotMagenta)
        )
        return Mesh3D(v, edges, faces)
    }

    fun createOctahedron(size: Float = 110f): Mesh3D {
        val s = size / 1.4f
        val v = listOf(
            Vec3(0f, -s * 1.3f, 0f),  // Top 0
            Vec3(-s, 0f, 0f),         // Left 1
            Vec3(0f, 0f, -s),         // Back 2
            Vec3(s, 0f, 0f),          // Right 3
            Vec3(0f, 0f, s),          // Front 4
            Vec3(0f, s * 1.3f, 0f)    // Bottom 5
        )
        val edges = listOf(
            0 to 1, 0 to 2, 0 to 3, 0 to 4,
            5 to 1, 5 to 2, 5 to 3, 5 to 4,
            1 to 4, 4 to 3, 3 to 2, 2 to 1
        )
        val faces = listOf(
            MeshFace(listOf(0, 4, 1), NeonCyan),
            MeshFace(listOf(0, 3, 4), HotMagenta),
            MeshFace(listOf(0, 2, 3), LiquidGold),
            MeshFace(listOf(0, 1, 2), MatrixGreen),
            MeshFace(listOf(5, 1, 4), HotMagenta),
            MeshFace(listOf(5, 4, 3), NeonCyan),
            MeshFace(listOf(5, 3, 2), MatrixGreen),
            MeshFace(listOf(5, 2, 1), LiquidGold)
        )
        return Mesh3D(v, edges, faces)
    }

    fun createPyramid(size: Float = 100f): Mesh3D {
        val s = size / 2f
        val h = size * 0.8f
        val v = listOf(
            Vec3(0f, -h / 2f, 0f), // Apex 0
            Vec3(-s, h / 2f, -s),  // Base FL 1
            Vec3(s, h / 2f, -s),   // Base FR 2
            Vec3(s, h / 2f, s),    // Base BR 3
            Vec3(-s, h / 2f, s)    // Base BL 4
        )
        val edges = listOf(
            0 to 1, 0 to 2, 0 to 3, 0 to 4,
            1 to 2, 2 to 3, 3 to 4, 4 to 1
        )
        val faces = listOf(
            MeshFace(listOf(0, 2, 1), NeonCyan),
            MeshFace(listOf(0, 3, 2), HotMagenta),
            MeshFace(listOf(0, 4, 3), LiquidGold),
            MeshFace(listOf(0, 1, 4), MatrixGreen),
            MeshFace(listOf(1, 2, 3, 4), CyberBorder)
        )
        return Mesh3D(v, edges, faces)
    }

    fun createTorus(radius: Float = 60f, tubeRadius: Float = 20f, segR: Int = 10, segT: Int = 8): Mesh3D {
        val vertices = mutableListOf<Vec3>()
        val edges = mutableListOf<Pair<Int, Int>>()
        val faces = mutableListOf<MeshFace>()

        for (i in 0 until segR) {
            val u = i * 2f * Math.PI.toFloat() / segR
            for (j in 0 until segT) {
                val vAngle = j * 2f * Math.PI.toFloat() / segT
                val x = (radius + tubeRadius * cos(vAngle)) * cos(u)
                val y = (radius + tubeRadius * cos(vAngle)) * sin(u)
                val z = tubeRadius * sin(vAngle)
                vertices.add(Vec3(x, y, z))
            }
        }

        for (i in 0 until segR) {
            val nextI = (i + 1) % segR
            for (j in 0 until segT) {
                val nextJ = (j + 1) % segT
                val idx1 = i * segT + j
                val idx2 = nextI * segT + j
                val idx3 = nextI * segT + nextJ
                val idx4 = i * segT + nextJ

                edges.add(idx1 to idx2)
                edges.add(idx1 to idx4)

                val color = if ((i + j) % 2 == 0) NeonCyan else HotMagenta
                faces.add(MeshFace(listOf(idx1, idx2, idx3, idx4), color))
            }
        }
        return Mesh3D(vertices, edges, faces)
    }
}

/**
 * High-performance 3D Holographic Canvas Composable with Touch Rotation and Auto-Orbit
 */
@Composable
fun Cyber3DHologramView(
    modifier: Modifier = Modifier,
    meshType: MeshShapeType = MeshShapeType.CYBER_CUBE,
    glowColor: Color = NeonCyan,
    showFaces: Boolean = true,
    showWireframe: Boolean = true,
    showVertices: Boolean = true,
    allowTouchRotate: Boolean = true,
    scale: Float = 1.0f
) {
    var userRotX by remember { mutableFloatStateOf(0.35f) }
    var userRotY by remember { mutableFloatStateOf(0.45f) }

    val infiniteTransition = rememberInfiniteTransition(label = "3d_auto_orbit")
    val autoAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (2f * Math.PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(12000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "auto_angle"
    )

    val mesh = remember(meshType) {
        when (meshType) {
            MeshShapeType.CYBER_CUBE -> MeshFactory.createCube(110f)
            MeshShapeType.NEON_OCTAHEDRON -> MeshFactory.createOctahedron(120f)
            MeshShapeType.QUANTUM_PYRAMID -> MeshFactory.createPyramid(110f)
            MeshShapeType.AETHER_TORUS -> MeshFactory.createTorus(65f, 22f, 10, 8)
        }
    }

    val touchModifier = if (allowTouchRotate) {
        Modifier.pointerInput(Unit) {
            detectDragGestures { change, dragAmount ->
                change.consume()
                userRotY += dragAmount.x * 0.015f
                userRotX -= dragAmount.y * 0.015f
            }
        }
    } else Modifier

    Canvas(
        modifier = modifier
            .then(touchModifier)
            .fillMaxSize()
    ) {
        val cx = size.width / 2f
        val cy = size.height / 2f
        val fov = 350f * scale
        val cameraDist = 320f

        val totalRotX = userRotX + sin(autoAngle * 0.5f) * 0.15f
        val totalRotY = userRotY + autoAngle
        val totalRotZ = cos(autoAngle * 0.3f) * 0.1f

        // Transform vertices
        val transformed = mesh.vertices.map { v ->
            v.rotateX(totalRotX).rotateY(totalRotY).rotateZ(totalRotZ)
        }

        // Project 3D to 2D
        val projected = transformed.map { v ->
            val zEff = v.z + cameraDist
            val pers = if (zEff > 10f) fov / zEff else 1f
            Offset(cx + v.x * pers, cy + v.y * pers)
        }

        val lightDir = Vec3(0.5f, -0.7f, 1f).normalized()

        // 1. Draw Translucent Lit Faces (Depth sorted from back to front)
        if (showFaces) {
            val sortedFaces = mesh.faces.map { face ->
                val avgZ = face.vIndices.map { transformed[it].z }.average().toFloat()
                face to avgZ
            }.sortedBy { it.second } // Painter's algorithm

            for ((face, _) in sortedFaces) {
                if (face.vIndices.size < 3) continue
                val p0 = transformed[face.vIndices[0]]
                val p1 = transformed[face.vIndices[1]]
                val p2 = transformed[face.vIndices[2]]

                // Calculate normal
                val edge1 = p1 - p0
                val edge2 = p2 - p0
                val normal = edge1.cross(edge2).normalized()

                // Face culling check (facing camera or draw translucent)
                val dotNormal = normal.dot(Vec3(0f, 0f, 1f))
                val isFront = dotNormal > -0.2f

                val lightFactor = (normal.dot(lightDir).coerceIn(0.1f, 1.0f))
                val alpha = if (isFront) (0.25f + lightFactor * 0.35f) else 0.10f

                val path = Path()
                val firstPt = projected[face.vIndices[0]]
                path.moveTo(firstPt.x, firstPt.y)
                for (i in 1 until face.vIndices.size) {
                    val pt = projected[face.vIndices[i]]
                    path.lineTo(pt.x, pt.y)
                }
                path.close()

                drawPath(
                    path = path,
                    color = face.baseColor.copy(alpha = alpha),
                    style = Fill
                )
            }
        }

        // 2. Draw Wireframe Glowing Edges
        if (showWireframe) {
            for ((i1, i2) in mesh.edges) {
                val pt1 = projected[i1]
                val pt2 = projected[i2]
                val avgZ = (transformed[i1].z + transformed[i2].z) / 2f
                val depthAlpha = ((avgZ + 150f) / 300f).coerceIn(0.35f, 1.0f)

                // Outer glow line
                drawLine(
                    color = glowColor.copy(alpha = 0.25f * depthAlpha),
                    start = pt1,
                    end = pt2,
                    strokeWidth = 4f
                )
                // Core sharp beam
                drawLine(
                    color = Color.White.copy(alpha = 0.85f * depthAlpha),
                    start = pt1,
                    end = pt2,
                    strokeWidth = 1.5f
                )
            }
        }

        // 3. Draw Vertex Nodes
        if (showVertices) {
            for (i in projected.indices) {
                val pt = projected[i]
                val z = transformed[i].z
                val nodeAlpha = ((z + 150f) / 300f).coerceIn(0.4f, 1f)
                drawCircle(
                    color = glowColor.copy(alpha = 0.4f * nodeAlpha),
                    radius = 4.5f,
                    center = pt
                )
                drawCircle(
                    color = Color.White.copy(alpha = 0.9f * nodeAlpha),
                    radius = 2.0f,
                    center = pt
                )
            }
        }
    }
}

/**
 * Interactive 3D Hologram Laboratory Card in the Arcade Hub
 */
@Composable
fun Interactive3DHologramCard(
    modifier: Modifier = Modifier
) {
    var selectedShapeIndex by remember { mutableIntStateOf(0) }
    val shapes = MeshShapeType.values()
    val currentShape = shapes[selectedShapeIndex]

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        shape = RoundedCornerShape(22.dp),
        color = CyberSurface,
        border = androidx.compose.foundation.BorderStroke(1.2.dp, NeonCyan.copy(alpha = 0.7f))
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = NeonCyan.copy(alpha = 0.2f),
                        border = androidx.compose.foundation.BorderStroke(0.8.dp, NeonCyan.copy(alpha = 0.8f))
                    ) {
                        Text(
                            text = "3D ENGINE",
                            color = NeonCyan,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                        )
                    }
                    Text(
                        text = "REAL-TIME 3D HOLOGRAM",
                        color = TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                // Switch Shape Button
                Surface(
                    onClick = {
                        selectedShapeIndex = (selectedShapeIndex + 1) % shapes.size
                    },
                    shape = RoundedCornerShape(12.dp),
                    color = CyberDark,
                    border = androidx.compose.foundation.BorderStroke(1.dp, HotMagenta.copy(alpha = 0.6f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ChangeCircle,
                            contentDescription = "Switch Shape",
                            tint = HotMagenta,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = currentShape.label,
                            color = HotMagenta,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }

            Text(
                text = "Touch & drag anywhere on the hologram to rotate in full 3D space with specular lighting.",
                color = TextTertiary,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
            )

            // 3D Canvas Viewport
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(
                        Brush.radialGradient(
                            listOf(
                                NeonCyan.copy(alpha = 0.12f),
                                CyberDark.copy(alpha = 0.95f)
                            )
                        )
                    )
                    .border(
                        1.dp,
                        Brush.linearGradient(listOf(NeonCyan.copy(alpha = 0.5f), HotMagenta.copy(alpha = 0.5f))),
                        RoundedCornerShape(16.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Cyber3DHologramView(
                    meshType = currentShape,
                    glowColor = if (selectedShapeIndex % 2 == 0) NeonCyan else HotMagenta,
                    allowTouchRotate = true,
                    scale = 1.05f
                )

                // 3D Rotation hint badge
                Row(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Sync,
                        contentDescription = null,
                        tint = NeonCyan.copy(alpha = 0.7f),
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = "DRAG TO ROTATE 360°",
                        color = NeonCyan.copy(alpha = 0.8f),
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
