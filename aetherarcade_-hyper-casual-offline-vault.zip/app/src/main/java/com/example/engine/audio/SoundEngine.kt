package com.example.engine.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.concurrent.Executors
import kotlin.math.PI
import kotlin.math.sin
import kotlin.random.Random

class SoundEngine private constructor() {

    private val audioScope = CoroutineScope(Dispatchers.Default)
    private val audioExecutor = Executors.newFixedThreadPool(2)
    private val sampleRate = 44100

    private val _isSoundEnabled = MutableStateFlow(true)
    val isSoundEnabled: StateFlow<Boolean> = _isSoundEnabled.asStateFlow()

    private val _isAmbientMusicEnabled = MutableStateFlow(false)
    val isAmbientMusicEnabled: StateFlow<Boolean> = _isAmbientMusicEnabled.asStateFlow()

    private val _masterVolume = MutableStateFlow(0.85f)
    val masterVolume: StateFlow<Boolean> = MutableStateFlow(true) // helper state

    private val _audioVisualizerLevels = MutableStateFlow(FloatArray(12) { 0.1f })
    val audioVisualizerLevels: StateFlow<FloatArray> = _audioVisualizerLevels.asStateFlow()

    private var ambientJob: Job? = null

    companion object {
        val instance: SoundEngine by lazy { SoundEngine() }
    }

    fun setSoundEnabled(enabled: Boolean) {
        _isSoundEnabled.value = enabled
        if (!enabled && _isAmbientMusicEnabled.value) {
            setAmbientMusicEnabled(false)
        }
    }

    fun setAmbientMusicEnabled(enabled: Boolean) {
        _isAmbientMusicEnabled.value = enabled
        if (enabled) {
            startAmbientSynthesizer()
        } else {
            ambientJob?.cancel()
            ambientJob = null
        }
    }

    private fun pulseVisualizer(intensity: Float) {
        val levels = FloatArray(12) { i ->
            val factor = 1f - kotlin.math.abs(i - 6) / 7f
            (intensity * factor * (0.6f + Random.nextFloat() * 0.4f)).coerceIn(0.05f, 1f)
        }
        _audioVisualizerLevels.value = levels
    }

    private fun playRawPcm(samples: ShortArray) {
        if (!_isSoundEnabled.value) return
        audioExecutor.execute {
            try {
                val bufferSize = samples.size * 2
                val track = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_GAME)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sampleRate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(bufferSize)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()

                track.write(samples, 0, samples.size)
                track.play()

                // Small delay to allow playback and clean up
                Thread.sleep((samples.size * 1000L) / sampleRate + 20)
                track.stop()
                track.release()
            } catch (_: Exception) {
                // Ignore audio hardware transient exceptions
            }
        }
    }

    /**
     * Crisp retro Laser Ping (frequency sweep from 980Hz down to 240Hz)
     */
    fun playLaserPing() {
        pulseVisualizer(0.8f)
        audioScope.launch {
            val durationMs = 120
            val numSamples = (sampleRate * (durationMs / 1000f)).toInt()
            val samples = ShortArray(numSamples)
            var phase = 0.0

            for (i in 0 until numSamples) {
                val progress = i.toDouble() / numSamples
                val freq = 980.0 * (1.0 - progress * 0.75)
                phase += 2.0 * PI * freq / sampleRate
                val envelope = 1.0 - progress
                val sample = (sin(phase) * envelope * 0.7 * Short.MAX_VALUE).toInt()
                samples[i] = sample.coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
            }
            playRawPcm(samples)
        }
    }

    /**
     * Deep punchy Bass Thump (e.g., collisions, paddle rebounds, wall hits)
     */
    fun playBassThump() {
        pulseVisualizer(0.9f)
        audioScope.launch {
            val durationMs = 110
            val numSamples = (sampleRate * (durationMs / 1000f)).toInt()
            val samples = ShortArray(numSamples)
            var phase = 0.0

            for (i in 0 until numSamples) {
                val progress = i.toDouble() / numSamples
                val freq = 120.0 * (1.0 - progress * 0.6)
                phase += 2.0 * PI * freq / sampleRate
                val envelope = (1.0 - progress) * (1.0 - progress)
                val noise = (Random.nextFloat() * 2f - 1f) * 0.15f * (1.0 - progress)
                val wave = sin(phase) * 0.85 + noise
                samples[i] = (wave * envelope * Short.MAX_VALUE).toInt().toShort()
            }
            playRawPcm(samples)
        }
    }

    /**
     * High-crystal Score Chime (arpeggio crystal tones: E5 -> G#5 -> B5 -> E6)
     */
    fun playScoreChime() {
        pulseVisualizer(0.75f)
        audioScope.launch {
            val frequencies = doubleArrayOf(659.25, 830.61, 987.77, 1318.51)
            val noteDurationMs = 45
            val totalSamples = (sampleRate * (noteDurationMs * 4 / 1000f)).toInt()
            val samples = ShortArray(totalSamples)
            var sampleIdx = 0

            for (freq in frequencies) {
                val noteSamples = (sampleRate * (noteDurationMs / 1000f)).toInt()
                var phase = 0.0
                for (i in 0 until noteSamples) {
                    if (sampleIdx >= totalSamples) break
                    val progress = i.toDouble() / noteSamples
                    phase += 2.0 * PI * freq / sampleRate
                    // Harmonic overtone for shimmering crystal sound
                    val harmonic = sin(phase * 2.0) * 0.3
                    val envelope = 1.0 - progress * 0.6
                    val wave = (sin(phase) + harmonic) * envelope * 0.55
                    samples[sampleIdx++] = (wave * Short.MAX_VALUE).toInt().toShort()
                }
            }
            playRawPcm(samples)
        }
    }

    /**
     * Brick Shatter / Particle Crunch
     */
    fun playBrickBreak() {
        pulseVisualizer(0.85f)
        audioScope.launch {
            val durationMs = 90
            val numSamples = (sampleRate * (durationMs / 1000f)).toInt()
            val samples = ShortArray(numSamples)
            var phase = 0.0

            for (i in 0 until numSamples) {
                val progress = i.toDouble() / numSamples
                phase += 2.0 * PI * 340.0 / sampleRate
                val square = if (sin(phase) > 0) 0.3 else -0.3
                val noise = (Random.nextFloat() * 2f - 1f) * 0.7f
                val envelope = (1.0 - progress)
                val wave = (square + noise) * envelope * 0.65
                samples[i] = (wave * Short.MAX_VALUE).toInt().toShort()
            }
            playRawPcm(samples)
        }
    }

    /**
     * Rising Gravity Flip / Warp Sweep (160Hz -> 720Hz)
     */
    fun playGravityFlip() {
        pulseVisualizer(0.7f)
        audioScope.launch {
            val durationMs = 130
            val numSamples = (sampleRate * (durationMs / 1000f)).toInt()
            val samples = ShortArray(numSamples)
            var phase = 0.0

            for (i in 0 until numSamples) {
                val progress = i.toDouble() / numSamples
                val freq = 160.0 + (720.0 - 160.0) * progress * progress
                phase += 2.0 * PI * freq / sampleRate
                val envelope = sin(progress * PI)
                val wave = sin(phase) * envelope * 0.75
                samples[i] = (wave * Short.MAX_VALUE).toInt().toShort()
            }
            playRawPcm(samples)
        }
    }

    /**
     * 2048 Tile Merge Chime (harmonious double chime)
     */
    fun playMergeChime(tier: Int = 1) {
        pulseVisualizer(0.9f)
        audioScope.launch {
            val baseFreq = 440.0 + (tier.coerceAtMost(10) * 55.0)
            val durationMs = 160
            val numSamples = (sampleRate * (durationMs / 1000f)).toInt()
            val samples = ShortArray(numSamples)
            var phase1 = 0.0
            var phase2 = 0.0

            for (i in 0 until numSamples) {
                val progress = i.toDouble() / numSamples
                phase1 += 2.0 * PI * baseFreq / sampleRate
                phase2 += 2.0 * PI * (baseFreq * 1.5) / sampleRate // Perfect fifth
                val envelope = (1.0 - progress) * (1.0 - progress)
                val wave = (sin(phase1) * 0.6 + sin(phase2) * 0.4) * envelope * 0.7
                samples[i] = (wave * Short.MAX_VALUE).toInt().toShort()
            }
            playRawPcm(samples)
        }
    }

    /**
     * Power-up Ascension Fanfare
     */
    fun playPowerUp() {
        pulseVisualizer(1.0f)
        audioScope.launch {
            val notes = doubleArrayOf(523.25, 659.25, 783.99, 1046.50) // C5, E5, G5, C6
            val noteDurationMs = 50
            val totalSamples = (sampleRate * (noteDurationMs * 4 / 1000f)).toInt()
            val samples = ShortArray(totalSamples)
            var idx = 0

            for (freq in notes) {
                val count = (sampleRate * (noteDurationMs / 1000f)).toInt()
                var phase = 0.0
                for (i in 0 until count) {
                    if (idx >= totalSamples) break
                    val progress = i.toDouble() / count
                    phase += 2.0 * PI * freq / sampleRate
                    val wave = (if (sin(phase) > 0) 0.5 else -0.5) * (1.0 - progress * 0.4) * 0.5
                    samples[idx++] = (wave * Short.MAX_VALUE).toInt().toShort()
                }
            }
            playRawPcm(samples)
        }
    }

    /**
     * Subtle UI Click / Card Tap
     */
    fun playTactileBlip() {
        audioScope.launch {
            val durationMs = 15
            val numSamples = (sampleRate * (durationMs / 1000f)).toInt()
            val samples = ShortArray(numSamples)
            var phase = 0.0
            for (i in 0 until numSamples) {
                val progress = i.toDouble() / numSamples
                phase += 2.0 * PI * 1400.0 / sampleRate
                val wave = sin(phase) * (1.0 - progress) * 0.3
                samples[i] = (wave * Short.MAX_VALUE).toInt().toShort()
            }
            playRawPcm(samples)
        }
    }

    /**
     * Game Over Descent Chord
     */
    fun playGameOverChord() {
        pulseVisualizer(0.8f)
        audioScope.launch {
            val durationMs = 380
            val numSamples = (sampleRate * (durationMs / 1000f)).toInt()
            val samples = ShortArray(numSamples)
            var phase1 = 0.0
            var phase2 = 0.0

            for (i in 0 until numSamples) {
                val progress = i.toDouble() / numSamples
                val freq1 = 280.0 * (1.0 - progress * 0.45)
                val freq2 = 233.0 * (1.0 - progress * 0.45) // Minor interval
                phase1 += 2.0 * PI * freq1 / sampleRate
                phase2 += 2.0 * PI * freq2 / sampleRate
                val envelope = (1.0 - progress)
                val wave = (sin(phase1) * 0.5 + sin(phase2) * 0.5) * envelope * 0.6
                samples[i] = (wave * Short.MAX_VALUE).toInt().toShort()
            }
            playRawPcm(samples)
        }
    }

    /**
     * Background Ambient Synth Drone
     */
    private fun startAmbientSynthesizer() {
        ambientJob?.cancel()
        ambientJob = audioScope.launch {
            val chordProgressions = listOf(
                doubleArrayOf(130.81, 196.00, 261.63), // C3, G3, C4
                doubleArrayOf(116.54, 174.61, 233.08), // Bb2, F3, Bb3
                doubleArrayOf(146.83, 220.00, 293.66), // D3, A3, D4
                doubleArrayOf(103.83, 155.56, 207.65)  // Ab2, Eb3, Ab3
            )

            var chordIndex = 0
            while (isActive && _isAmbientMusicEnabled.value && _isSoundEnabled.value) {
                val chord = chordProgressions[chordIndex % chordProgressions.size]
                chordIndex++

                val chordDurationSec = 3.2
                val numSamples = (sampleRate * chordDurationSec).toInt()
                val samples = ShortArray(numSamples)

                val phases = DoubleArray(chord.size) { 0.0 }

                for (i in 0 until numSamples) {
                    val progress = i.toDouble() / numSamples
                    val envelope = sin(progress * PI) * 0.15 // gentle soothing volume

                    var waveAcc = 0.0
                    for (c in chord.indices) {
                        phases[c] += 2.0 * PI * chord[c] / sampleRate
                        waveAcc += sin(phases[c]) / chord.size
                    }

                    samples[i] = (waveAcc * envelope * Short.MAX_VALUE).toInt().toShort()
                }

                playRawPcm(samples)
                pulseVisualizer(0.35f)
                delay(3100)
            }
        }
    }
}
