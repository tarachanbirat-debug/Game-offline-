package com.example.engine.fx

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import com.example.ui.theme.CyberDark
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.HotMagenta
import com.example.ui.theme.NeonCyan
import kotlin.random.Random

data class StardustParticle(
    val x: Float,
    val y: Float,
    val speed: Float,
    val size: Float,
    val color: Color
)

@Composable
fun Retro3DHorizonBackground(
    modifier: Modifier = Modifier,
    neonColor: Color = NeonCyan,
    accentColor: Color = HotMagenta,
    speedFactor: Float = 1.0f
) {
    val infiniteTransition = rememberInfiniteTransition(label = "3d_horizon_scroll")
    val gridScroll by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween((1400 / speedFactor).toInt(), easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "grid_scroll"
    )

    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.85f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(2400, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "sun_pulse"
    )

    val particles = remember {
        List(35) {
            StardustParticle(
                x = Random.nextFloat(),
                y = Random.nextFloat(),
                speed = Random.nextFloat() * 0.4f + 0.2f,
                size = Random.nextFloat() * 2.5f + 1.2f,
                color = if (Random.nextBoolean()) NeonCyan else HotMagenta
            )
        }
    }

    Canvas(modifier = modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height

        // Deep cyber sky gradient
        drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(
                    CyberDark,
                    Color(0xFF0D1127),
                    Color(0xFF160E2A)
                ),
                startY = 0f,
                endY = h
            )
        )

        val horizonY = h * 0.62f
        val cx = w / 2f

        // Distant Glowing Neon Pulsar / 3D Sun
        val sunRadius = 55f * pulseScale
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    accentColor.copy(alpha = 0.7f),
                    accentColor.copy(alpha = 0.25f),
                    Color.Transparent
                ),
                center = Offset(cx, horizonY - 10f),
                radius = sunRadius * 2.2f
            ),
            center = Offset(cx, horizonY - 10f),
            radius = sunRadius * 2.2f
        )
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    Color.White,
                    accentColor,
                    accentColor.copy(alpha = 0f)
                ),
                center = Offset(cx, horizonY - 10f),
                radius = sunRadius
            ),
            center = Offset(cx, horizonY - 10f),
            radius = sunRadius
        )

        // 3D Perspective Grid - Floor
        val numVerticalLines = 14
        val spread = w * 1.6f

        // Draw radiating vertical lines converging at (cx, horizonY)
        for (i in -numVerticalLines / 2..numVerticalLines / 2) {
            val bottomX = cx + (i / (numVerticalLines / 2f)) * spread
            val alpha = (1f - (kotlin.math.abs(i) / (numVerticalLines * 0.6f))).coerceIn(0.15f, 0.6f)
            drawLine(
                color = neonColor.copy(alpha = alpha),
                start = Offset(cx, horizonY),
                end = Offset(bottomX, h),
                strokeWidth = 1.3f
            )
        }

        // Draw horizontal grid lines moving forward in 3D depth
        val numHorizLines = 10
        for (i in 0 until numHorizLines) {
            val z = (i + gridScroll) / numHorizLines.toFloat() // 0 to 1
            // Perspective transform: lines are close together near horizon and spread apart near bottom
            val curve = z * z
            val y = horizonY + curve * (h - horizonY)
            val lineAlpha = (curve * 0.7f).coerceIn(0.08f, 0.75f)

            drawLine(
                color = neonColor.copy(alpha = lineAlpha),
                start = Offset(0f, y),
                end = Offset(w, y),
                strokeWidth = 1.0f + curve * 1.8f
            )
        }

        // Horizon Neon Glow Line
        drawLine(
            brush = Brush.horizontalGradient(
                colors = listOf(
                    Color.Transparent,
                    neonColor,
                    Color.White,
                    accentColor,
                    Color.Transparent
                )
            ),
            start = Offset(0f, horizonY),
            end = Offset(w, horizonY),
            strokeWidth = 2.5f
        )

        // Floating 3D Stardust Particles
        for (p in particles) {
            val curY = ((p.y + (gridScroll * p.speed)) % 1f) * (horizonY - 20f)
            val curX = p.x * w
            val starAlpha = (1f - (curY / horizonY)).coerceIn(0.2f, 0.9f)
            drawCircle(
                color = p.color.copy(alpha = starAlpha),
                radius = p.size,
                center = Offset(curX, curY)
            )
        }
    }
}
