package com.example.engine.fx

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

data class Particle(
    var x: Float,
    var y: Float,
    var vx: Float,
    var vy: Float,
    var radius: Float,
    val color: Color,
    var alpha: Float = 1f,
    val maxLife: Float,
    var life: Float = maxLife,
    val decay: Float = 1f
)

class ParticleSystem(private val maxParticles: Int = 220) {

    private val particles = ArrayList<Particle>(maxParticles)

    fun burst(
        x: Float,
        y: Float,
        count: Int = 18,
        colors: List<Color>,
        minSpeed: Float = 3f,
        maxSpeed: Float = 12f,
        minRadius: Float = 3f,
        maxRadius: Float = 7f,
        lifespan: Float = 1f
    ) {
        val safeCount = count.coerceAtMost(maxParticles - particles.size)
        for (i in 0 until safeCount) {
            val angle = Random.nextFloat() * 2f * Math.PI.toFloat()
            val speed = minSpeed + Random.nextFloat() * (maxSpeed - minSpeed)
            val vx = cos(angle) * speed
            val vy = sin(angle) * speed
            val radius = minRadius + Random.nextFloat() * (maxRadius - minRadius)
            val color = colors[Random.nextInt(colors.size)]
            val life = lifespan * (0.6f + Random.nextFloat() * 0.4f)

            particles.add(
                Particle(
                    x = x,
                    y = y,
                    vx = vx,
                    vy = vy,
                    radius = radius,
                    color = color,
                    alpha = 1f,
                    maxLife = life,
                    life = life
                )
            )
        }
    }

    fun emitJet(
        x: Float,
        y: Float,
        color: Color,
        vxOffset: Float = -4f,
        spreadY: Float = 2f
    ) {
        if (particles.size >= maxParticles) return
        particles.add(
            Particle(
                x = x,
                y = y,
                vx = vxOffset + (Random.nextFloat() - 0.5f) * 1.5f,
                vy = (Random.nextFloat() - 0.5f) * spreadY,
                radius = 2.5f + Random.nextFloat() * 3f,
                color = color,
                alpha = 0.9f,
                maxLife = 0.35f,
                life = 0.35f
            )
        )
    }

    fun update(dt: Float) {
        val iterator = particles.iterator()
        while (iterator.hasNext()) {
            val p = iterator.next()
            p.life -= dt
            if (p.life <= 0f) {
                iterator.remove()
                continue
            }
            p.x += p.vx
            p.y += p.vy
            p.vx *= 0.96f
            p.vy *= 0.96f
            p.alpha = (p.life / p.maxLife).coerceIn(0f, 1f)
        }
    }

    fun render(drawScope: DrawScope) {
        for (i in particles.indices) {
            val p = particles[i]
            if (p.alpha <= 0.02f) continue
            // Outer soft glow
            drawScope.drawCircle(
                color = p.color.copy(alpha = p.alpha * 0.4f),
                radius = p.radius * 1.8f,
                center = Offset(p.x, p.y)
            )
            // Bright solid core
            drawScope.drawCircle(
                color = Color.White.copy(alpha = p.alpha * 0.9f),
                radius = p.radius * 0.5f,
                center = Offset(p.x, p.y)
            )
        }
    }

    fun clear() {
        particles.clear()
    }
}
