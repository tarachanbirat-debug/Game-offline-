package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.VaultProfileEntity
import com.example.engine.fx.Retro3DHorizonBackground
import com.example.games.aetherblaster.AetherBlasterGame
import com.example.games.brickbreaker.BrickBreakerGame
import com.example.games.cybersnake.CyberSnakeGame
import com.example.games.gravitydash.GravityDashGame
import com.example.games.prism2048.Prism2048Game
import com.example.games.quantumreflex.QuantumReflexGame
import com.example.ui.components.CrtScanlinesOverlay
import com.example.ui.components.FloatingGlassDock
import com.example.ui.screens.ArcadeHubScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.SoundDeckScreen
import com.example.ui.screens.TrophiesScreen
import com.example.ui.theme.AetherArcadeTheme
import com.example.ui.theme.CyberDark
import com.example.viewmodel.ArcadeViewModel
import com.example.viewmodel.VaultTab

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AetherArcadeTheme {
                ArcadeRootApp()
            }
        }
    }
}

@Composable
fun ArcadeRootApp(
    viewModel: ArcadeViewModel = viewModel()
) {
    val currentTab by viewModel.currentTab.collectAsState()
    val activeGame by viewModel.activeGame.collectAsState()
    val crtEnabled by viewModel.crtScanlinesEnabled.collectAsState()
    val allStats by viewModel.allGameStats.collectAsState()
    val profile by viewModel.profile.collectAsState()
    val trophies by viewModel.trophies.collectAsState()
    val selectedCategory by viewModel.selectedCategory.collectAsState()

    val safeProfile = profile ?: VaultProfileEntity()

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = CyberDark
    ) {
        val currentGame = activeGame

        if (currentGame != null) {
            // Handle system back button to exit game to lobby
            BackHandler {
                viewModel.exitGameToLobby()
            }

            val gameStat = allStats.find { it.gameId == currentGame.id }
            val bestScore = gameStat?.highScore ?: 0L

            when (currentGame.id) {
                "brick_breaker" -> {
                    BrickBreakerGame(
                        soundEngine = viewModel.soundEngine,
                        hapticEngine = viewModel.hapticEngine,
                        crtEnabled = crtEnabled,
                        bestHighScore = bestScore,
                        onScoreFinished = { score, streak ->
                            viewModel.recordGameScore(currentGame.id, currentGame.title, score, streak)
                        },
                        onExitGame = { viewModel.exitGameToLobby() }
                    )
                }
                "cyber_snake" -> {
                    CyberSnakeGame(
                        soundEngine = viewModel.soundEngine,
                        hapticEngine = viewModel.hapticEngine,
                        crtEnabled = crtEnabled,
                        bestHighScore = bestScore,
                        onScoreFinished = { score, streak ->
                            viewModel.recordGameScore(currentGame.id, currentGame.title, score, streak)
                        },
                        onExitGame = { viewModel.exitGameToLobby() }
                    )
                }
                "gravity_dash" -> {
                    GravityDashGame(
                        soundEngine = viewModel.soundEngine,
                        hapticEngine = viewModel.hapticEngine,
                        crtEnabled = crtEnabled,
                        bestHighScore = bestScore,
                        onScoreFinished = { score, streak ->
                            viewModel.recordGameScore(currentGame.id, currentGame.title, score, streak)
                        },
                        onExitGame = { viewModel.exitGameToLobby() }
                    )
                }
                "prism_2048" -> {
                    Prism2048Game(
                        soundEngine = viewModel.soundEngine,
                        hapticEngine = viewModel.hapticEngine,
                        crtEnabled = crtEnabled,
                        bestHighScore = bestScore,
                        onScoreFinished = { score, streak ->
                            viewModel.recordGameScore(currentGame.id, currentGame.title, score, streak)
                        },
                        onExitGame = { viewModel.exitGameToLobby() }
                    )
                }
                "quantum_reflex" -> {
                    QuantumReflexGame(
                        soundEngine = viewModel.soundEngine,
                        hapticEngine = viewModel.hapticEngine,
                        crtEnabled = crtEnabled,
                        bestHighScore = bestScore,
                        onScoreFinished = { score, streak ->
                            viewModel.recordGameScore(currentGame.id, currentGame.title, score, streak)
                        },
                        onExitGame = { viewModel.exitGameToLobby() }
                    )
                }
                "aether_blaster" -> {
                    AetherBlasterGame(
                        soundEngine = viewModel.soundEngine,
                        hapticEngine = viewModel.hapticEngine,
                        crtEnabled = crtEnabled,
                        bestHighScore = bestScore,
                        onScoreFinished = { score, streak ->
                            viewModel.recordGameScore(currentGame.id, currentGame.title, score, streak)
                        },
                        onExitGame = { viewModel.exitGameToLobby() }
                    )
                }
                else -> {
                    viewModel.exitGameToLobby()
                }
            }
        } else {
            // Main Vault Hub & Navigation Shell
            Box(modifier = Modifier.fillMaxSize()) {
                // Dynamic Animated 3D Retro Horizon Grid with moving perspective lines & stardust
                Retro3DHorizonBackground(speedFactor = 0.7f)

                AnimatedContent(
                    targetState = currentTab,
                    transitionSpec = { fadeIn() togetherWith fadeOut() },
                    label = "tab_switch"
                ) { target ->
                    when (target) {
                        VaultTab.HUB -> {
                            ArcadeHubScreen(
                                profile = safeProfile,
                                gameStats = allStats,
                                selectedCategory = selectedCategory,
                                onSelectCategory = { viewModel.setCategory(it) },
                                onLaunchGame = { id, title, cat ->
                                    viewModel.launchGame(id, title, cat)
                                }
                            )
                        }
                        VaultTab.TROPHIES -> {
                            TrophiesScreen(
                                profile = safeProfile,
                                trophies = trophies
                            )
                        }
                        VaultTab.SOUND_DECK -> {
                            SoundDeckScreen(
                                soundEngine = viewModel.soundEngine
                            )
                        }
                        VaultTab.SETTINGS -> {
                            SettingsScreen(
                                profile = safeProfile,
                                onToggleCrt = { viewModel.toggleCrtScanlines() },
                                onToggleShake = { viewModel.toggleScreenShake() },
                                onToggleHaptics = { viewModel.toggleHaptics() },
                                onToggleSound = { viewModel.toggleSound() },
                                onResetData = { viewModel.resetAllData() }
                            )
                        }
                    }
                }

                // Global CRT Scanlines Overlay
                CrtScanlinesOverlay(enabled = crtEnabled)

                // Floating Glassmorphic Cyber Dock
                FloatingGlassDock(
                    currentTab = currentTab,
                    onSelectTab = { viewModel.selectTab(it) },
                    modifier = Modifier.align(Alignment.BottomCenter)
                )
            }
        }
    }
}
